import React, { useState, useEffect, useCallback } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import BUILD_INFO from './CACHE_BUSTER';
// Mock backend desabilitado em v1.0.103.305 - Sistema usa apenas Supabase
import { setOfflineMode } from './utils/offlineConfig';
import { useCalendarManager } from './hooks/useCalendarManager';
import { MainSidebar } from './components/MainSidebar';
import { ModulePlaceholder } from './components/ModulePlaceholder';
import { VersionBadge } from './components/VersionBadge';
import { BuildLogger } from './components/BuildLogger';
import LoginPage from './components/LoginPage';
import { Calendar } from './components/CalendarGrid';
import { PriceEditModal } from './components/PriceEditModal';
import { PropertySidebar } from './components/PropertySidebar';
import { CalendarHeader } from './components/CalendarHeader';
import { QuickActionsModal } from './components/QuickActionsModal';
import { ReservationPreviewModal } from './components/ReservationPreviewModal';
import { ReservationDetailsModal } from './components/ReservationDetailsModal';
import { CreateReservationWizard } from './components/CreateReservationWizard';
import { MinNightsEditModal } from './components/MinNightsEditModal';
import { BlockModal } from './components/BlockModal';
import { BlockDetailsModal } from './components/BlockDetailsModal';
import { QuotationModal } from './components/QuotationModal';
import { ListView } from './components/ListView';
import { TimelineView } from './components/TimelineView';
import { ExportModal } from './components/ExportModal';
import { TagsManagementModal } from './components/TagsManagementModal';
import { EditReservationWizard } from './components/EditReservationWizard';
import { PriceTiersModal } from './components/PriceTiersModal';
import { SeasonalityModal } from './components/SeasonalityModal';
import { CancelReservationModal } from './components/CancelReservationModal';
import { LocationsManager } from './components/LocationsManager';
import { IconsPreview } from './components/IconsPreview';
import { FontSelector } from './components/FontSelector';
import { SettingsPanel } from './components/SettingsPanel';
import { DatabaseInitializer } from './components/DatabaseInitializer';

import { ConflictAlert } from './components/ConflictAlert';
import { DashboardInicial } from './components/DashboardInicial';
import { DashboardInicialSimple } from './components/DashboardInicialSimple';
import { AdminMasterFunctional } from './components/AdminMasterFunctional';
import { TenantManagement } from './components/TenantManagement';
import { UserManagement } from './components/UserManagement';
import { ClientsAndGuestsManagement } from './components/ClientsAndGuestsManagement';
import { ProprietariosManagement } from './components/ProprietariosManagement';
import { DocumentosListasClientes } from './components/DocumentosListasClientes';
import { ReservationsManagement } from './components/ReservationsManagement';
import { BookingComIntegration } from './components/BookingComIntegration';
import { LocationsAndListings } from './components/LocationsAndListings';
import { PropertiesManagement } from './components/PropertiesManagement';
import { DiagnosticoImovel } from './components/DiagnosticoImovel';
import { SettingsManager } from './components/SettingsManager';
import { BulkPricingManager } from './components/BulkPricingManager';
import { ChatInbox } from './components/ChatInbox';
import { ChatInboxWithEvolution } from './components/ChatInboxWithEvolution';
import { GuestsManager } from './components/GuestsManager';
import { ClientSitesManager } from './components/ClientSitesManager';
import { NotFoundPage } from './components/NotFoundPage';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';
import { EmergencyRouter } from './components/EmergencyRouter';
import { EmergencyRecovery } from './components/EmergencyRecovery';
import { PropertyWizardPage } from './pages/PropertyWizardPage';
import DiagnosticoImovelPage from './pages/DiagnosticoImovelPage';
import { FigmaTestPropertyCreator } from './components/FigmaTestPropertyCreator';
import FinanceiroModule from './components/financeiro/FinanceiroModule';
import FinanceiroDashboard from './components/financeiro/FinanceiroDashboard';
import { ContasReceberPage } from './components/financeiro/pages/ContasReceberPage';
import { ContasPagarPage } from './components/financeiro/pages/ContasPagarPage';
import { LancamentosPage } from './components/financeiro/pages/LancamentosPage';
import { DREPage } from './components/financeiro/pages/DREPage';
import { FluxoCaixaPage } from './components/financeiro/pages/FluxoCaixaPage';
import CRMTasksModule from './components/crm/CRMTasksModule';
import CRMTasksDashboard from './components/crm/CRMTasksDashboard';
import BIModule from './components/bi/BIModule';
import BIDashboard from './components/bi/BIDashboard';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { LanguageSwitcher } from './components/LanguageSwitcher';
import { AppRouter } from './components/AppRouter';
import { LoadingProgress } from './components/LoadingProgress';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner';
import ErrorBoundary from './components/ErrorBoundary';

import { initAutoRecovery } from './utils/autoRecovery';
import { ChevronLeft, ChevronRight, Plus, Filter, Download, Tag, Sparkles, TrendingUp, Database, AlertTriangle } from 'lucide-react';
import { detectConflicts } from './utils/conflictDetection';
import { initializeEvolutionContactsService, getEvolutionContactsService } from './utils/services/evolutionContactsService';
import { Button } from './components/ui/button';
import { reservationsApi, guestsApi, propertiesApi, calendarApi } from './utils/api';
import { cn } from './components/ui/utils';

// Types
export interface Property {
  id: string;
  name: string;
  image: string;
  type: string;
  location: string;
  tarifGroup: string;
  tags?: string[];
}

export interface Reservation {
  id: string;
  propertyId: string;
  guestName: string;
  checkIn: Date;
  checkOut: Date;
  status: 'confirmed' | 'pending' | 'blocked' | 'maintenance';
  platform: 'airbnb' | 'booking' | 'direct' | 'decolar';
  price: number;
  nights: number;
}

export interface PriceRule {
  id: string;
  propertyId: string;
  startDate: Date;
  endDate: Date;
  daysOfWeek: number[]; // 0-6 (Dom-Sáb)
  basePrice: number;
}

// ============================================================================
// ⚠️ MOCK DATA REMOVIDO v1.0.103.308 (05/11/2025)
// Sistema agora carrega APENAS dados reais do Supabase
// Sem fallbacks para mock - se API falhar, mostra erro apropriado
// ============================================================================

function App() {
  const [activeModule, setActiveModule] = useState('painel-inicial');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date(2025, 9, 1)); // October 2025
  const [properties, setProperties] = useState<Property[]>([]);
  const [selectedProperties, setSelectedProperties] = useState<string[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [blocks, setBlocks] = useState<any[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);
  const [loadingProperties, setLoadingProperties] = useState(false);
  const [showErrorBanner, setShowErrorBanner] = useState(false);
  const [errorBannerDismissed, setErrorBannerDismissed] = useState(false); // Novo: rastreia se foi dispensado
  const [initialLoading, setInitialLoading] = useState(false); // 🔥 FORÇA FALSE - sem loading!
  
  // 🔥 DEBUG - Log estado inicial
  useEffect(() => {
    console.log('🟢 APP MONTOU COM SUCESSO!');
    console.log('📊 Estado inicial:', {
      activeModule,
      properties: properties.length,
      reservations: reservations.length,
      initialLoading,
      sidebarCollapsed
    });
  }, []); // Roda só uma vez no mount

  // ✅ ETAPA 4 - Inicializar Evolution Contacts Service
  useEffect(() => {
    console.log('🔄 Inicializando Evolution Contacts Service...');
    initializeEvolutionContactsService();

    // Cleanup: parar sincronização ao desmontar
    return () => {
      const service = getEvolutionContactsService();
      service?.stopAutoSync();
      console.log('🛑 Evolution Contacts Service parado');
    };
  }, []);
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date }>({
    from: new Date(2025, 9, 24), // Oct 24
    to: new Date(2025, 10, 11) // Nov 11
  });

  // 🚨 FIX v1.0.103.153: Garantir que loading nunca fica travado
  useEffect(() => {
    // Se loading ainda estiver ativo após 5 segundos, força desativar
    const emergencyTimeout = setTimeout(() => {
      if (initialLoading || loadingProperties) {
        console.error('🚨 EMERGENCY FIX: Loading travado detectado!');
        console.log('🔧 Forçando finalização do loading...');
        setInitialLoading(false);
        setLoadingProperties(false);
        toast.success('Sistema carregado (modo emergência)');
      }
    }, 5000);

    return () => clearTimeout(emergencyTimeout);
  }, [initialLoading, loadingProperties]);

  // 🚀 SISTEMA DE AUTO-RECUPERAÇÃO v1.0.103.157 - DESABILITADO
  useEffect(() => {
    console.log('⚠️ Auto-recuperação DESABILITADA (v1.0.103.157)');
    // 🔥 DESABILITADO - estava causando loop infinito
    // initAutoRecovery();
    
    // 🔥 DESABILITADO v1.0.103.268 - Mock Mode removido para testes com dados reais
    // enableMockMode();
    // setOfflineMode(true);
    
    // Limpar dados mock do localStorage (sistema agora usa apenas Supabase)
    const mockDataKeys = ['rendizy_mock_data', 'rendizy_mock_enabled', 'rendizy_data_version'];
    mockDataKeys.forEach(key => {
      if (localStorage.getItem(key)) {
        localStorage.removeItem(key);
        console.log(`🗑️ Removido: ${key}`);
      }
    });
    
    console.log('✅ Sistema rodando em modo PRODUÇÃO (sem mock data).');
    
    // 📱 DESABILITADO v1.0.103.169 - Evolution Contacts Service
    // Evita "Failed to fetch" quando backend está offline
    /*
    try {
      const { initializeEvolutionContactsService } = require('./utils/services/evolutionContactsService');
      initializeEvolutionContactsService();
      console.log('✅ Evolution Contacts Service iniciado - Sync automática a cada 5 min');
    } catch (error) {
      console.warn('⚠️ Evolution Contacts Service não pôde ser iniciado:', error);
    }
    */
    console.log('⚠️ Evolution Contacts Service DESABILITADO - Evita erro quando backend offline');
  }, []);

  const [selectedReservationTypes, setSelectedReservationTypes] = useState<string[]>([
    'pre-reserva',
    'reserva',
    'contrato',
    'bloqueado',
    'manutencao',
    'cancelada'
  ]);
  
  const [priceEditModal, setPriceEditModal] = useState<{
    open: boolean;
    propertyId?: string;
    startDate?: Date;
    endDate?: Date;
  }>({ open: false });

  const [minNightsModal, setMinNightsModal] = useState<{
    open: boolean;
    propertyId?: string;
    startDate?: Date;
    endDate?: Date;
  }>({ open: false });

  const [quickActionsModal, setQuickActionsModal] = useState<{
    open: boolean;
    propertyId?: string;
    startDate?: Date;
    endDate?: Date;
  }>({ open: false });

  const [reservationPreviewModal, setReservationPreviewModal] = useState<{
    open: boolean;
    reservation?: Reservation;
  }>({ open: false });

  const [createReservationWizard, setCreateReservationWizard] = useState<{
    open: boolean;
    propertyId?: string;
    startDate?: Date;
    endDate?: Date;
  }>({ open: false });

  const [blockModal, setBlockModal] = useState<{
    open: boolean;
    propertyId?: string;
    startDate?: Date;
    endDate?: Date;
  }>({ open: false });

  const [blockDetailsModal, setBlockDetailsModal] = useState<{
    open: boolean;
    block?: any;
  }>({ open: false });

  const [quotationModal, setQuotationModal] = useState<{
    open: boolean;
    propertyId?: string;
    startDate?: Date;
    endDate?: Date;
  }>({ open: false });

  const [reservationDetailsModal, setReservationDetailsModal] = useState<{
    open: boolean;
    reservation?: Reservation;
  }>({ open: false });

  const [exportModal, setExportModal] = useState(false);
  const [tagsModal, setTagsModal] = useState(false);
  const [currentView, setCurrentView] = useState<'calendar' | 'list' | 'timeline'>('calendar');
  
  const [editReservationWizard, setEditReservationWizard] = useState<{
    open: boolean;
    reservation?: Reservation;
  }>({ open: false });

  const [priceTiersModal, setPriceTiersModal] = useState<{
    open: boolean;
    propertyId?: string;
    startDate?: Date;
    endDate?: Date;
  }>({ open: false });

  const [seasonalityModal, setSeasonalityModal] = useState<{
    open: boolean;
    propertyId?: string;
  }>({ open: false });

  const [cancelReservationModal, setCancelReservationModal] = useState<{
    open: boolean;
    reservation?: Reservation;
  }>({ open: false });

  const [databaseInitModal, setDatabaseInitModal] = useState(false);
  const [conflicts, setConflicts] = useState<any[]>([]);
  const [showConflictAlert, setShowConflictAlert] = useState(true);

  // ⚠️ FUNÇÃO REMOVIDA v1.0.103.308 - Não há mais "force load" com mock
  // Sistema carrega apenas dados reais do Supabase

  // 🔥 DESABILITADO - initialLoading já começa como false!
  /*
  // Log build info on mount + Force load imediato
  useEffect(() => {
    console.log('🎯 APP INITIALIZED - BUILD INFO:', BUILD_INFO);
    console.log('📅 Version:', BUILD_INFO.version);
    console.log('🔨 Build:', BUILD_INFO.build);
    console.log('⏰ Timestamp:', BUILD_INFO.timestamp);
    console.log('�� Changes:', BUILD_INFO.changes);
    console.log('⚡ [AUTO-LOAD] initialLoading inicial:', initialLoading);
    
    // 🔥 FORCE LOAD IMEDIATO - sem dependências, roda apenas 1 vez
    console.log('⚡ [AUTO-LOAD] Iniciando carregamento...');
    const loadTimer = setTimeout(() => {
      console.log('⚡ [AUTO-LOAD] Timeout disparado! Carregando dados...');
      setProperties(mockProperties);
      setSelectedProperties(mockProperties.map(p => p.id));
      setReservations(mockReservations);
      setBlocks([]);
      setLoadingProperties(false);
      setInitialLoading(false);
      console.log('✅ [AUTO-LOAD] initialLoading setado para FALSE!');
      toast.success('Sistema carregado!');
    }, 100);
    
    return () => {
      console.log('⚠️ [AUTO-LOAD] Cleanup');
      clearTimeout(loadTimer);
    };
  }, []); // ✅ Array vazio = roda apenas 1 vez, sem loop
  */
  
  // Log apenas uma vez
  console.log('🎯 APP INITIALIZED - v1.0.103.233 - initialLoading:', initialLoading);
  
  // ⚠️ BRUTAL FIX REMOVIDO v1.0.103.308 - Sistema carrega dados reais do Supabase

  // Detectar conflitos sempre que as reservas mudarem
  useEffect(() => {
    const { conflicts: detectedConflicts, reservationsWithConflicts } = detectConflicts(
      reservations,
      properties
    );
    
    setConflicts(detectedConflicts);
    
    // Atualizar reservas com flag de conflito
    if (detectedConflicts.length > 0) {
      setReservations(reservationsWithConflicts as Reservation[]);
      console.warn('⚠️ OVERBOOKING DETECTADO:', {
        conflictsCount: detectedConflicts.length,
        conflicts: detectedConflicts
      });
    }
  }, [reservations.length]);

  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  const prevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const handlePriceEdit = (propertyId: string, startDate: Date, endDate: Date) => {
    setPriceEditModal({
      open: true,
      propertyId,
      startDate,
      endDate
    });
  };

  const handlePriceSave = (rule: Omit<PriceRule, 'id'>) => {
    console.log('💰 Salvando regra de preço:', rule);
    console.log('📦 Build Info:', BUILD_INFO);
    toast.success('Preços atualizados com sucesso!');
    setPriceEditModal({ open: false });
  };

  const handleMinNightsEdit = (propertyId: string, startDate: Date, endDate: Date) => {
    setMinNightsModal({
      open: true,
      propertyId,
      startDate,
      endDate
    });
  };

  const handleMinNightsSave = (data: any) => {
    console.log('Salvando mínimo de noites:', data);
    toast.success('Mínimo de noites atualizado!');
    setMinNightsModal({ open: false });
  };

  const handleEmptyClick = (propertyId: string, startDate: Date, endDate: Date) => {
    setQuickActionsModal({
      open: true,
      propertyId,
      startDate,
      endDate
    });
  };

  const handleQuickAction = (action: 'reservation' | 'quote' | 'predictive' | 'maintenance' | 'tiers' | 'seasonality') => {
    const { propertyId, startDate, endDate } = quickActionsModal;
    setQuickActionsModal({ open: false });
    
    if (action === 'reservation') {
      setCreateReservationWizard({
        open: true,
        propertyId,
        startDate,
        endDate
      });
    } else if (action === 'quote') {
      setQuotationModal({
        open: true,
        propertyId,
        startDate,
        endDate
      });
    } else if (action === 'predictive' || action === 'maintenance' || action === 'block') {
      // Todos os tipos de bloqueio usam o mesmo modal unificado
      setBlockModal({
        open: true,
        propertyId,
        startDate,
        endDate
      });
    } else if (action === 'tiers') {
      setPriceTiersModal({
        open: true,
        propertyId,
        startDate,
        endDate
      });
    } else if (action === 'seasonality') {
      setSeasonalityModal({
        open: true,
        propertyId
      });
    }
  };

  const handleReservationClick = (reservation: Reservation) => {
    setReservationPreviewModal({
      open: true,
      reservation
    });
  };

  const handleOpenReservationDetails = () => {
    const reservation = reservationPreviewModal.reservation;
    setReservationPreviewModal({ open: false });
    if (reservation) {
      setReservationDetailsModal({
        open: true,
        reservation
      });
    }
  };

  const handleOpenBlockDetails = (block: any) => {
    setBlockDetailsModal({
      open: true,
      block
    });
  };

  const handleBlockUpdate = () => {
    // Atualizar lista de bloqueios e reservas
    setRefreshKey(prev => prev + 1);
  };

  const handleBlockDelete = () => {
    // Atualizar lista de bloqueios e reservas
    setRefreshKey(prev => prev + 1);
  };

  // Initialize mock mode and check data consistency on mount
  useEffect(() => {
    // 🔥 DESABILITADO v1.0.103.268 - Mock mode removido para testes com dados reais
    // enableMockMode();
    console.log('✅ Sistema em modo PRODUÇÃO (backend real)');
    
    const checkDataConsistency = () => {
      try {
        const mockData = localStorage.getItem('rendizy_mock_data');
        if (mockData) {
          const data = JSON.parse(mockData);
          // Check if there are reservations with invalid propertyIds
          if (data.reservations && data.properties) {
            const propertyIds = new Set(data.properties.map((p: any) => p.id));
            const hasInvalidReservations = data.reservations.some(
              (r: any) => !propertyIds.has(r.propertyId)
            );
            if (hasInvalidReservations) {
              console.warn('⚠️ Dados inconsistentes detectados no localStorage');
              console.log('🟣 Ativando banner de erro');
              if (!errorBannerDismissed) {
                setShowErrorBanner(true);
              }
            } else {
              console.log('✅ Dados consistentes no localStorage');
            }
          }
        }
      } catch (error) {
        console.error('Erro ao verificar consistência dos dados:', error);
      }
    };
    
    checkDataConsistency();
  }, []);

  // Load properties from API - ✅ HABILITADO v1.0.103.308
  useEffect(() => {
    const loadProperties = async () => {
      setLoadingProperties(true);
      console.log('🔄 Carregando propriedades do Supabase...');
      
      try {
        const response = await propertiesApi.list();
        console.log('✅ Resposta da API de propriedades:', response);
        
        if (response.success && response.data) {
          const apiProperties = response.data.map((p: any) => ({
            id: p.id || '',
            name: p.internalName || p.name || 'Sem nome',
            image: p.photos?.[0] || 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=100&h=100&fit=crop',
            type: p.type || 'Casa',
            location: `${p.address?.city || 'N/A'}, ${p.address?.state || 'N/A'}`,
            tarifGroup: p.tarifGroup || 'Padrão',
            tags: p.tags || []
          })).filter((p: Property) => p.id);
          
          console.log(`✅ ${apiProperties.length} propriedades carregadas do Supabase`);
          setProperties(apiProperties);
          setSelectedProperties(apiProperties.map((p: Property) => p.id));
        } else {
          console.log('ℹ️ Nenhuma propriedade encontrada no Supabase');
          setProperties([]);
          setSelectedProperties([]);
        }
      } catch (error) {
        console.error('❌ Erro ao carregar propriedades:', error);
        if (!errorBannerDismissed) {
          setShowErrorBanner(true);
        }
        toast.error('Erro ao carregar propriedades. Verifique sua conexão.');
        setProperties([]);
        setSelectedProperties([]);
      } finally {
        setLoadingProperties(false);
        setInitialLoading(false);
      }
    };

    loadProperties();
  }, [errorBannerDismissed]);

  // Load reservations from API - ✅ HABILITADO v1.0.103.308
  useEffect(() => {
    const loadReservations = async () => {
      console.log('🔄 Carregando reservas do Supabase...');
      
      try {
        // Calcular intervalo de datas (3 meses antes até 6 meses depois)
        const today = new Date();
        const startDate = new Date(today.getFullYear(), today.getMonth() - 3, 1);
        const endDate = new Date(today.getFullYear(), today.getMonth() + 6, 30);
        
        const [reservationsResponse, guestsResponse, calendarResponse] = await Promise.all([
          reservationsApi.list(),
          guestsApi.list(),
          calendarApi.getData({
            startDate: startDate.toISOString().split('T')[0],
            endDate: endDate.toISOString().split('T')[0],
            includeBlocks: true,
            includePrices: false
          })
        ]);
        
        if (reservationsResponse.success && reservationsResponse.data) {
          const guests = guestsResponse.data || [];
          
          // Convert API reservations to App Reservation format
          const apiReservations = reservationsResponse.data.map((r: any) => {
            const guest = guests.find((g: any) => g.id === r.guestId);
            
            // Parse dates properly to avoid timezone issues
            const [ciYear, ciMonth, ciDay] = r.checkIn.split('-').map(Number);
            const [coYear, coMonth, coDay] = r.checkOut.split('-').map(Number);
            
            return {
              id: r.id,
              propertyId: r.propertyId,
              guestName: guest ? guest.fullName : 'Hóspede',
              checkIn: new Date(ciYear, ciMonth - 1, ciDay),
              checkOut: new Date(coYear, coMonth - 1, coDay),
              status: r.status,
              platform: r.platform,
              price: r.pricing.total / 100, // Convert cents to reais
              nights: r.nights
            };
          });
          
          console.log(`✅ ${apiReservations.length} reservas carregadas do Supabase`);
          setReservations(apiReservations);
          
          // Carregar bloqueios do calendário
          if (calendarResponse.success && calendarResponse.data?.blocks) {
            console.log(`✅ ${calendarResponse.data.blocks.length} bloqueios carregados`);
            setBlocks(calendarResponse.data.blocks);
          } else {
            setBlocks([]);
          }
        } else {
          console.log('ℹ️ Nenhuma reserva encontrada no Supabase');
          setReservations([]);
          setBlocks([]);
          if (reservationsResponse.error) {
            console.error('❌ Erro na API:', reservationsResponse.error);
            if (!errorBannerDismissed) {
              setShowErrorBanner(true);
            }
          }
        }
      } catch (error) {
        console.error('❌ Erro ao carregar reservas:', error);
        toast.error('Erro ao carregar reservas. Verifique sua conexão.');
        setReservations([]);
        setBlocks([]);
        if (!errorBannerDismissed) {
          setShowErrorBanner(true);
        }
      }
    };

    loadReservations();
  }, [refreshKey, errorBannerDismissed]);

  // ========================================================================
  // CALENDAR MANAGER - AGENDA VIVA (5 ANOS SEMPRE À FRENTE)
  // ========================================================================
  
  // Memoizar funções para evitar loop infinito
  const getCurrentLastDay = useCallback(() => {
    const today = new Date();
    const fiveYearsAhead = new Date();
    fiveYearsAhead.setFullYear(today.getFullYear() + 5);
    return fiveYearsAhead;
  }, []);

  const handleDaysAdded = useCallback(async (days: any[]) => {
    console.log(`📅 AGENDA ESTENDIDA: ${days.length} novos dias adicionados!`);
    console.log(`   → Primeiro dia: ${days[0]?.date}`);
    console.log(`   → Último dia: ${days[days.length - 1]?.date}`);
    
    // TODO: Enviar para o backend quando integrado
    // await calendarApi.extendCalendar(days);
    
    toast.success(
      `Agenda estendida! ${days.length} novos dias adicionados.`,
      {
        description: `Novo horizonte até ${days[days.length - 1]?.date}`,
        duration: 5000
      }
    );
  }, []);

  const calendarManager = useCalendarManager({
    getCurrentLastDay,
    onDaysAdded: handleDaysAdded,
    enabled: true
  });

  // ========================================================================

  const handleReservationComplete = (data: any) => {
    console.log('Reserva criada:', data);
    toast.success('Reserva criada com sucesso!');
    setCreateReservationWizard({ open: false });
    // Refresh reservations
    setRefreshKey(prev => prev + 1);
  };

  const handleEditReservationComplete = (data: {
    reservationId: string;
    guestName: string;
    guestEmail?: string;
    guestPhone?: string;
    checkIn: Date;
    checkOut: Date;
    totalPrice: number;
    notes?: string;
    sendEmail: boolean;
  }) => {
    console.log('✏️ Editando reserva:', data);
    
    // Atualiza a reserva no estado
    setReservations(prev => prev.map(reservation => {
      if (reservation.id === data.reservationId) {
        // Calcula o novo número de noites
        const nights = Math.ceil(
          (data.checkOut.getTime() - data.checkIn.getTime()) / (1000 * 60 * 60 * 24)
        );
        
        return {
          ...reservation,
          guestName: data.guestName,
          checkIn: data.checkIn,
          checkOut: data.checkOut,
          price: data.totalPrice,
          nights: nights
        };
      }
      return reservation;
    }));
    
    // Log para debug
    console.log('📦 Build Info:', BUILD_INFO);
    
    // Fecha o wizard
    setEditReservationWizard({ open: false });
    
    // Toast já é mostrado pelo EditReservationWizard
  };

  // Função para buscar reserva por código e navegar até ela
  const handleSearchReservation = async (searchQuery: string) => {
    // Detectar se é um código de reserva (RSV-XXXXXX)
    const reservationCodePattern = /^RSV-[A-Z0-9]{6}$/i;
    
    if (reservationCodePattern.test(searchQuery.trim())) {
      console.log('🔍 Buscando reserva:', searchQuery);
      
      // Buscar a reserva nos dados carregados
      const reservation = reservations.find(r => 
        r.id.toUpperCase() === searchQuery.trim().toUpperCase()
      );
      
      if (reservation) {
        console.log('✅ Reserva encontrada:', reservation);
        
        // 1. Navegar para o calendário
        setActiveModule('calendario');
        
        // 2. Ajustar mês para o check-in da reserva
        const checkInMonth = new Date(reservation.checkIn);
        setCurrentMonth(new Date(checkInMonth.getFullYear(), checkInMonth.getMonth(), 1));
        
        // 3. Selecionar a propriedade da reserva
        if (!selectedProperties.includes(reservation.propertyId)) {
          setSelectedProperties(prev => [...prev, reservation.propertyId]);
        }
        
        // 4. Mostrar preview da reserva após navegação
        setTimeout(() => {
          setReservationPreviewModal({
            open: true,
            reservation
          });
        }, 300);
        
        toast.success(`Reserva ${reservation.id} encontrada!`);
        return true;
      } else {
        console.log('❌ Reserva não encontrada:', searchQuery);
        toast.error(`Reserva ${searchQuery} não encontrada`);
        return false;
      }
    }
    
    return false; // Não é um código de reserva
  };

  // Função de busca avançada (busca em tudo)
  const handleAdvancedSearch = (query: string): any[] => {
    if (!query || query.trim().length < 2) {
      return [];
    }

    const normalizedQuery = query.toLowerCase().trim();
    const results: any[] = [];

    // 1. Buscar em RESERVAS por código
    const reservationCodePattern = /^RSV-[A-Z0-9]{6}$/i;
    if (reservationCodePattern.test(query.trim())) {
      const matchingReservations = reservations.filter(r =>
        r.id.toUpperCase().includes(query.trim().toUpperCase())
      );
      matchingReservations.forEach(r => {
        const property = properties.find(p => p.id === r.propertyId);
        results.push({
          type: 'reservation',
          id: r.id,
          title: r.id,
          subtitle: `${r.guestName} • ${property?.name || 'Imóvel'} • ${r.nights} noites`,
          icon: 'Calendar' as const,
          data: r
        });
      });
    }

    // 2. Buscar em HÓSPEDES por nome
    const matchingGuests = reservations.filter(r =>
      r.guestName.toLowerCase().includes(normalizedQuery)
    );
    matchingGuests.forEach(r => {
      const property = properties.find(p => p.id === r.propertyId);
      results.push({
        type: 'guest',
        id: `guest-${r.id}`,
        title: r.guestName,
        subtitle: `${r.id} • ${property?.name || 'Imóvel'} • ${new Date(r.checkIn).toLocaleDateString('pt-BR')}`,
        icon: 'User' as const,
        data: r
      });
    });

    // 3. Buscar em PROPRIEDADES por nome ou localização
    const matchingProperties = properties.filter(p =>
      p.name.toLowerCase().includes(normalizedQuery) ||
      p.location.toLowerCase().includes(normalizedQuery) ||
      p.type.toLowerCase().includes(normalizedQuery)
    );
    matchingProperties.forEach(p => {
      const reservationCount = reservations.filter(r => r.propertyId === p.id).length;
      results.push({
        type: 'property',
        id: p.id,
        title: p.name,
        subtitle: `${p.type} • ${p.location} • ${reservationCount} reservas`,
        icon: 'Home' as const,
        data: p
      });
    });

    // Limitar a 10 resultados
    return results.slice(0, 10);
  };

  // Debug: log do estado do banner
  console.log('🎯 Estado do banner de erro:', showErrorBanner);
  console.log('✅ App renderizando...');

  return (
    <BrowserRouter>
      <ErrorBoundary>
        <ThemeProvider>
          <LanguageProvider>
        {/* 🔥 EMERGENCY ROUTER DESABILITADO v1.0.103.244 - causava loops */}
        {/* <EmergencyRouter /> */}
        
        {/* Sincronização URL ↔ Módulo */}
        <AppRouter activeModule={activeModule} setActiveModule={setActiveModule} />
        
        {/* Componentes globais - sempre presentes */}
        <BuildLogger />
        <Toaster />
        
        <Routes>
        {/* ✅ ROTA LOGIN - v1.0.103.259 - Sistema Multi-Tenant */}
        <Route path="/login" element={<LoginPage />} />
        
        {/* 🧪 ROTA TESTE FIGMA - v1.0.103.311 - Criação de Imóvel de Teste */}
        <Route path="/test/figma-property" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <MainSidebar
              activeModule="test-figma"
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300 p-8",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="max-w-4xl mx-auto w-full">
                <div className="mb-6">
                  <h1 className="text-3xl mb-2">🧪 Teste Automatizado</h1>
                  <p className="text-gray-600 dark:text-gray-400">
                    Ferramenta de desenvolvimento para criação rápida de imóvel de teste "@figma@"
                  </p>
                </div>
                
                <FigmaTestPropertyCreator />
                
                <div className="mt-6 p-4 border border-blue-200 dark:border-blue-800 rounded-lg bg-blue-50 dark:bg-blue-950">
                  <p className="text-sm text-blue-900 dark:text-blue-100">
                    💡 <strong>Dica:</strong> Após criar o imóvel, acesse "Imóveis" no menu lateral para visualizá-lo.
                  </p>
                </div>
              </div>
            </div>
          </div>
        } />
        
        {/* ✅ ROTA CALENDÁRIO - v1.0.103.249 */}
        <Route path="/calendario" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='calendario'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex flex-1 overflow-hidden">
                {/* Property Sidebar */}
                <PropertySidebar
                  properties={properties}
                  selectedProperties={selectedProperties}
                  onToggleProperty={(id) => {
                    setSelectedProperties(prev => 
                      prev.includes(id) 
                        ? prev.filter(p => p !== id)
                        : [...prev, id]
                    );
                  }}
                  dateRange={dateRange}
                  onDateRangeChange={setDateRange}
                  selectedReservationTypes={selectedReservationTypes}
                  onReservationTypesChange={setSelectedReservationTypes}
                  currentView={currentView}
                  onViewChange={setCurrentView}
                />

                {/* Main Calendar Area */}
                <div className="flex-1 flex flex-col overflow-hidden">
                  {/* Calendar Header */}
                  <CalendarHeader
                    currentMonth={currentMonth}
                    onMonthChange={setCurrentMonth}
                    currentView={currentView}
                    onViewChange={setCurrentView}
                    dateRange={dateRange}
                    onDateRangeChange={setDateRange}
                    selectedProperties={selectedProperties}
                    selectedReservationTypes={selectedReservationTypes}
                    onReservationTypesChange={setSelectedReservationTypes}
                    onExport={() => setExportModal(true)}
                  />

                  {/* Calendar Views */}
                  <div className="flex-1 overflow-auto">
                    {currentView === 'calendar' && (
                      <Calendar
                        properties={properties.filter(p => selectedProperties.includes(p.id))}
                        reservations={reservations}
                        blocks={blocks}
                        currentMonth={currentMonth}
                        selectedReservationTypes={selectedReservationTypes}
                        onCellClick={handleEmptyClick}
                        onReservationClick={handleReservationClick}
                        onBlockClick={handleOpenBlockDetails}
                        refreshKey={refreshKey}
                      />
                    )}
                    
                    {currentView === 'list' && (
                      <ListView
                        properties={properties.filter(p => selectedProperties.includes(p.id))}
                        reservations={reservations}
                        selectedReservationTypes={selectedReservationTypes}
                        onReservationClick={handleReservationClick}
                      />
                    )}
                    
                    {currentView === 'timeline' && (
                      <TimelineView
                        properties={properties.filter(p => selectedProperties.includes(p.id))}
                        reservations={reservations}
                        blocks={blocks}
                        dateRange={dateRange}
                        selectedReservationTypes={selectedReservationTypes}
                        onReservationClick={handleReservationClick}
                        onBlockClick={handleOpenBlockDetails}
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        } />
        
        {/* ✅ ROTA RESERVAS - v1.0.103.253 */}
        <Route path="/reservations" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='central-reservas'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex-1 overflow-hidden">
                <ReservationsManagement />
              </div>
            </div>
          </div>
        } />
        
        {/* ✅ ROTA ADMIN MASTER - v1.0.103.253 */}
        <Route path="/admin" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='admin-master'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex-1 overflow-hidden">
                <AdminMasterFunctional />
              </div>
            </div>
          </div>
        } />
        
        {/* ✅ ROTA CHAT - v1.0.103.253 */}
        <Route path="/chat" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='central-mensagens'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex-1 overflow-hidden">
                <ChatInboxWithEvolution />
              </div>
            </div>
          </div>
        } />
        
        {/* ✅ ROTA LOCATIONS - v1.0.103.253 */}
        <Route path="/locations" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='locations-manager'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex-1 overflow-hidden">
                <LocationsAndListings />
              </div>
            </div>
          </div>
        } />
        
        {/* ✅ ROTA PRICING - v1.0.103.253 */}
        <Route path="/pricing" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='precos-em-lote'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex-1 overflow-hidden">
                <BulkPricingManager />
              </div>
            </div>
          </div>
        } />
        
        {/* ✅ ROTA INTEGRATIONS - v1.0.103.253 */}
        <Route path="/integrations" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='integracoes-bookingcom'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex-1 overflow-hidden">
                <BookingComIntegration />
              </div>
            </div>
          </div>
        } />
        
        {/* ✅ ROTA SITES CLIENTES - v1.0.103.253 */}
        <Route path="/sites-clientes" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='motor-reservas'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex-1 overflow-hidden">
                <ClientSitesManager />
              </div>
            </div>
          </div>
        } />
        
        {/* ✅ ROTA GUESTS - v1.0.103.253 */}
        <Route path="/guests" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='hospedes'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex-1 overflow-hidden">
                <GuestsManager />
              </div>
            </div>
          </div>
        } />
        
        {/* ✅ ROTA SETTINGS - v1.0.103.253 */}
        <Route path="/settings" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='configuracoes'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex-1 overflow-hidden">
                <SettingsManager />
              </div>
            </div>
          </div>
        } />
        
        {/* Módulo Financeiro - v1.0.103.234 */}
        <Route path="/financeiro/*" element={<FinanceiroModule />}>
          <Route index element={<FinanceiroDashboard />} />
          <Route path="plano-contas" element={<ModulePlaceholder module="Plano de Contas" />} />
          <Route path="lancamentos" element={<LancamentosPage />} />
          <Route path="centro-custos" element={<ModulePlaceholder module="Centro de Custos" />} />
          <Route path="contas-receber" element={<ContasReceberPage />} />
          <Route path="contas-pagar" element={<ContasPagarPage />} />
          <Route path="inadimplencia" element={<ModulePlaceholder module="Inadimplência" />} />
          <Route path="conciliacao" element={<ModulePlaceholder module="Conciliação Bancária" />} />
          <Route path="contas-bancarias" element={<ModulePlaceholder module="Contas Bancárias" />} />
          <Route path="dre" element={<DREPage />} />
          <Route path="fluxo-caixa" element={<FluxoCaixaPage />} />
          <Route path="relatorios" element={<ModulePlaceholder module="Relatórios Gerenciais" />} />
          <Route path="configuracoes" element={<ModulePlaceholder module="Configurações Financeiras" />} />
        </Route>
        
        {/* Módulo CRM & Tasks - Unificado */}
        <Route path="/crm/*" element={<CRMTasksModule />}>
          <Route index element={<CRMTasksDashboard />} />
          
          {/* Seção Clientes (CRM) */}
          <Route path="contatos" element={<ModulePlaceholder module="Contatos" />} />
          <Route path="leads" element={<ModulePlaceholder module="Leads" />} />
          <Route path="proprietarios" element={<ModulePlaceholder module="Proprietários" />} />
          
          {/* Seção Tarefas (Tasks) */}
          <Route path="minhas-tarefas" element={<ModulePlaceholder module="Minhas Tarefas" />} />
          <Route path="todas-tarefas" element={<ModulePlaceholder module="Todas as Tarefas" />} />
          <Route path="calendario-tarefas" element={<ModulePlaceholder module="Calendário de Tarefas" />} />
          <Route path="equipes" element={<ModulePlaceholder module="Equipes" />} />
          <Route path="prioridades" element={<ModulePlaceholder module="Prioridades" />} />
          
          {/* Seção Vendas (CRM) */}
          <Route path="pipeline" element={<ModulePlaceholder module="Pipeline de Vendas" />} />
          <Route path="propostas" element={<ModulePlaceholder module="Propostas" />} />
          <Route path="negocios" element={<ModulePlaceholder module="Negócios" />} />
          
          {/* Seção Comunicação (CRM) */}
          <Route path="emails" element={<ModulePlaceholder module="E-mails" />} />
          <Route path="chamadas" element={<ModulePlaceholder module="Chamadas" />} />
          <Route path="agenda" element={<ModulePlaceholder module="Agenda" />} />
          
          {/* Seção Análise */}
          <Route path="relatorios" element={<ModulePlaceholder module="Relatórios" />} />
          <Route path="tarefas-arquivadas" element={<ModulePlaceholder module="Tarefas Arquivadas" />} />
          
          {/* Configurações */}
          <Route path="configuracoes" element={<ModulePlaceholder module="Configurações CRM & Tasks" />} />
        </Route>
        
        {/* Módulo BI */}
        <Route path="/bi/*" element={<BIModule />}>
          <Route index element={<BIDashboard />} />
          <Route path="financeiro" element={<ModulePlaceholder module="Relatório Financeiro" />} />
          <Route path="ocupacao" element={<ModulePlaceholder module="Relatório de Ocupação" />} />
          <Route path="reservas" element={<ModulePlaceholder module="Relatório de Reservas" />} />
          <Route path="clientes" element={<ModulePlaceholder module="Relatório de Clientes" />} />
          <Route path="tendencias" element={<ModulePlaceholder module="Análise de Tendências" />} />
          <Route path="comparativos" element={<ModulePlaceholder module="Análises Comparativas" />} />
          <Route path="previsoes" element={<ModulePlaceholder module="Previsões" />} />
          <Route path="construtor" element={<ModulePlaceholder module="Construtor de Relatórios" />} />
          <Route path="meus-relatorios" element={<ModulePlaceholder module="Meus Relatórios" />} />
          <Route path="agendados" element={<ModulePlaceholder module="Relatórios Agendados" />} />
          <Route path="kpis" element={<ModulePlaceholder module="KPIs e Metas" />} />
          <Route path="configuracoes" element={<ModulePlaceholder module="Configurações BI" />} />
        </Route>
        
        {/* ✅ REABILITADO v1.0.103.174 - Rotas properties com MainSidebar sempre visível */}
        <Route path="/properties/new" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <MainSidebar
              activeModule='imoveis'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <PropertyWizardPage />
            </div>
          </div>
        } />
        
        <Route path="/properties/:id/edit" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <MainSidebar
              activeModule='imoveis'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <PropertyWizardPage />
            </div>
          </div>
        } />
        
        <Route path="/properties" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule='imoveis'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="flex-1 overflow-hidden">
                <PropertiesManagement />
              </div>
            </div>
          </div>
        } />
        
        {/* 🔍 ROTA DIAGNÓSTICO DE IMÓVEL - v1.0.103.314 */}
        <Route path="/properties/:id/diagnostico" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <MainSidebar
              activeModule='imoveis'
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300 p-8",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <div className="max-w-6xl mx-auto w-full">
                <DiagnosticoImovelPage />
              </div>
            </div>
          </div>
        } />
        
        {/* ⭐ ROTA CONVENCIONADA - Dashboard Inicial - v1.0.103.267 */}
        {/* URL FIXA para troubleshooting: /dashboard */}
        {/* Use esta URL quando precisar de um ponto de partida confiável */}
        <Route path="/dashboard" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule="painel-inicial"
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <DashboardInicialSimple
                conflicts={conflicts}
                onReservationClick={handleReservationClick}
                onDismissConflictAlert={() => setShowConflictAlert(false)}
                reservations={reservations}
                properties={properties}
              />
            </div>
          </div>
        } />
        
        {/* ⚡ Rota raiz - REDIRECT AUTOMÁTICO para /dashboard - v1.0.103.267 */}
        {/* Quando abrir preview (URL raiz /), redireciona automaticamente para /dashboard */}
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        
        
        {/* Rota 404 - Catch All - Renderiza Dashboard */}
        <Route path="*" element={
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <LoadingProgress 
              isLoading={initialLoading}
            />
            
            <MainSidebar
              activeModule="painel-inicial"
              onModuleChange={setActiveModule}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSearchReservation={handleSearchReservation}
              onAdvancedSearch={handleAdvancedSearch}
            />

            <div 
              className={cn(
                "flex flex-col min-h-screen transition-all duration-300",
                sidebarCollapsed ? "lg:ml-20" : "lg:ml-72"
              )}
            >
              <EmergencyRecovery />
            </div>
          </div>
        } />
        
        </Routes>
        
        {/* Botão Flutuante WhatsApp IA */}
        <WhatsAppFloatingButton />
          </LanguageProvider>
        </ThemeProvider>
      </ErrorBoundary>
    </BrowserRouter>
  );
}

// Helper functions para obter informações dos módulos
function getModuleName(moduleId: string): string {
  const moduleNames: Record<string, string> = {
    'admin-master': 'Admin Master',
    'painel-inicial': 'Dashboard Inicial',
    'locations-manager': 'Locais-Imóveis',
    'catalogo': 'Catálogo',
    'catalogo-grupos': 'Grupos',
    'catalogo-restricoes': 'Restrições dos Proprietários',
    'catalogo-regras': 'Regras Tarifárias',
    'catalogo-emails': 'Modelos de E-mail',
    'catalogo-impressao': 'Modelos para Impressão',
    'catalogo-midia': 'Gerenciador de Mídia',
    'central-reservas': 'Central de Reservas',
    'reservas-recepcao': 'Recepção',
    'reservas-fazer': 'Fazer Reserva',
    'reservas-achar': 'Achar Reserva',
    'reservas-incompletas': 'Reservas Incompletas',
    'reservas-avaliacoes-hospedes': 'Avaliações dos Hóspedes',
    'reservas-avaliacao-anfitriao': 'Avaliação do Anfitrião',
    'central-tarefas': 'Tasks',
    'tarefas-lista': 'Lista de Tarefas',
    'tarefas-dashboard-imagens': 'Dashboard de Imagens',
    'tarefas-dashboard-incutis': 'Dashboard Incutis',
    'tarefas-dashboard-guiaturs': 'Dashboard Guiaturs',
    'usuarios-hospedes': 'Usuários e Clientes',
    'usuarios-usuarios': 'Usuários',
    'usuarios-clientes': 'Clientes e Hóspedes',
    'usuarios-proprietarios': 'Proprietários',
    'usuarios-documentos-listas': 'Documentos e Listas de Clientes',
    'assistentes': 'Suporte',
    'assistentes-duplicados': 'E-mails Duplicados',
    'assistentes-perfis': 'Perfis de Cadastro',
    'assistentes-permissoes': 'Funções e Permissões',
    'assistentes-online': 'Usuários Online',
    'assistentes-atividade': 'Atividade dos Usuários',
    'assistentes-historico': 'Histórico de Login',
    'central-mensagens': 'Chat',
    'financeiro': 'Finanças',
    'estatisticas': 'Estatísticas',
    'configuracoes': 'Configurações',
    'motor-reservas': 'Edição de site',
    'app-center': 'Aplicativos',
    'backend-tester-tenants': 'Gerenciamento de Imobiliárias',
    'promocoes': 'Promoções',
    'notificacoes': 'Notificações'
  };
  return moduleNames[moduleId] || 'Módulo';
}

function getModuleDescription(moduleId: string): string {
  const descriptions: Record<string, string> = {
    'admin-master': 'Painel de controle administrativo exclusivo RENDIZY. Gerencie todas as imobiliárias, monitore o sistema e configure parâmetros globais.',
    'painel-inicial': 'Dashboard com visão geral do sistema, métricas principais e alertas importantes.',
    'locations-manager': 'Gerencie prédios, condomínios e localizações físicas. Nova estrutura hierárquica Location → Accommodation.',
    'catalogo': 'Organize e gerencie seus imóveis, grupos, tags e configurações de catálogo.',
    'catalogo-grupos': 'Crie e gerencie grupos/pastas para organizar seus imóveis.',
    'catalogo-restricoes': 'Configure restrições e preferências dos proprietários de imóveis.',
    'catalogo-regras': 'Defina regras tarifárias e políticas de precificação.',
    'catalogo-emails': 'Crie e edite modelos de e-mail para comunicação com hóspedes.',
    'catalogo-impressao': 'Configure modelos de documentos para impressão.',
    'catalogo-midia': 'Gerencie fotos, vídeos e outros arquivos de mídia dos imóveis.',
    'central-reservas': 'Centralize a gestão de todas as reservas de todas as plataformas.',
    'reservas-recepcao': 'Receba e processe novas solicitações de reserva.',
    'reservas-fazer': 'Crie novas reservas manualmente no sistema.',
    'reservas-achar': 'Busque e filtre reservas por diversos critérios.',
    'reservas-incompletas': 'Gerencie reservas pendentes ou com informações incompletas.',
    'reservas-avaliacoes-hospedes': 'Visualize e responda avaliações feitas pelos hóspedes.',
    'reservas-avaliacao-anfitriao': 'Avalie seus hóspedes após o check-out.',
    'central-tarefas': 'Organize e acompanhe tarefas relacionadas aos imóveis e reservas.',
    'tarefas-lista': 'Visualize e gerencie todas as tarefas do sistema.',
    'tarefas-dashboard-imagens': 'Dashboard para controle de qualidade de imagens dos imóveis.',
    'tarefas-dashboard-incutis': 'Painel de integração com Incutis.',
    'tarefas-dashboard-guiaturs': 'Painel de integração com Guiaturs.',
    'usuarios-hospedes': 'Gerencie usuários, clientes, hóspedes e proprietários.',
    'usuarios-usuarios': 'Administre usuários do sistema e suas permissões.',
    'usuarios-clientes': 'Gerencie clientes (compradores, locadores residenciais e hóspedes de temporada).',
    'usuarios-proprietarios': 'Administre informações dos proprietários de imóveis.',
    'usuarios-documentos-listas': 'Visualize e exporte listas de clientes, documentos, leads, compras e canais.',
    'assistentes': 'Ferramentas auxiliares para administração e manutenção do sistema.',
    'assistentes-duplicados': 'Identifique e mescle cadastros duplicados de e-mails.',
    'assistentes-perfis': 'Configure perfis padrão de cadastro.',
    'assistentes-permissoes': 'Gerencie funções e permissões de acesso.',
    'assistentes-online': 'Monitore usuários ativos no sistema.',
    'assistentes-atividade': 'Analise logs de atividade dos usuários.',
    'assistentes-historico': 'Visualize histórico completo de logins e acessos.',
    'central-mensagens': 'Central unificada de mensagens com WhatsApp, SMS, Email e chat interno.',
    'financeiro': 'Gestão financeira completa: contas a pagar/receber, DRE, fluxo de caixa e relatórios.',
    'estatisticas': 'Relatórios e análises detalhadas sobre desempenho e métricas.',
    'configuracoes': 'Configure preferências, integrações e parâmetros do sistema.',
    'motor-reservas': 'Crie e personalize sites de reservas com inteligência artificial.',
    'app-center': 'Central de aplicativos e integrações com plataformas externas.',
    'backend-tester-tenants': 'Ferramenta administrativa para gerenciar múltiplas imobiliárias (SaaS).',
    'promocoes': 'Crie e gerencie campanhas promocionais e descontos.',
    'notificacoes': 'Central de notificações e alertas do sistema.'
  };
  return descriptions[moduleId] || 'Módulo do sistema RENDIZY';
}

export default App;
