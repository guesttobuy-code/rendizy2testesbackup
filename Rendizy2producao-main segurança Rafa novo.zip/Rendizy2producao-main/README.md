
  # RENDIZY PRODUÇÃO

  This is a code bundle for RENDIZY PRODUÇÃO. The original project is available at https://www.figma.com/design/MIUsvRcBYzJU8Rfv4MA6Qg/RENDIZY-PRODU%C3%87%C3%83O.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  