/**
 * UTILS - Safe Database Operations
 * 
 * Helpers para operações seguras de banco de dados
 * Protege contra erros de triggers que esperam campos como updated_at
 * 
 * @version 1.0.103.400
 */

import { SupabaseClient } from 'jsr:@supabase/supabase-js@2';

/**
 * Remove campos que não existem na tabela antes de fazer upsert
 * Protege contra erros de triggers que esperam updated_at
 */
export function sanitizeDbData(data: any, fieldsToExclude: string[] = ['updated_at']): any {
  if (!data || typeof data !== 'object') {
    return data;
  }

  const sanitized = { ...data };
  
  // Remover campos que podem não existir
  for (const field of fieldsToExclude) {
    if (field in sanitized) {
      delete sanitized[field];
    }
  }

  return sanitized;
}

/**
 * Upsert seguro que não assume que updated_at existe
 * 
 * @param client - Supabase client
 * @param table - Nome da tabela
 * @param data - Dados para upsert
 * @param options - Opções do upsert
 * @param selectFields - Campos para selecionar (sem updated_at)
 */
export async function safeUpsert<T = any>(
  client: SupabaseClient,
  table: string,
  data: any,
  options: {
    onConflict?: string;
    ignoreDuplicates?: boolean;
  } = {},
  selectFields: string = '*'
): Promise<{ data: T | null; error: any }> {
  try {
    // Sanitizar dados removendo updated_at se presente
    const sanitizedData = sanitizeDbData(data, ['updated_at']);

    // Fazer upsert
    const query = client
      .from(table)
      .upsert(sanitizedData, {
        onConflict: options.onConflict,
        ignoreDuplicates: options.ignoreDuplicates ?? false,
      });

    // Selecionar campos explicitamente (sem updated_at)
    if (selectFields !== '*') {
      query.select(selectFields);
    } else {
      // Se selectFields for '*', não adicionar .select() para evitar problemas
      query.select();
    }

    const result = await query.single();

    return result;
  } catch (error: any) {
    console.error(`❌ [safeUpsert] Erro ao fazer upsert em ${table}:`, error);
    
    // Se o erro for relacionado a updated_at, tentar novamente sem esse campo
    if (error.message?.includes('updated_at') || error.message?.includes('has no field')) {
      console.log(`🔄 [safeUpsert] Tentando novamente sem updated_at...`);
      const sanitizedData = sanitizeDbData(data, ['updated_at']);
      
      try {
        const query = client
          .from(table)
          .upsert(sanitizedData, {
            onConflict: options.onConflict,
            ignoreDuplicates: options.ignoreDuplicates ?? false,
          })
          .select(selectFields !== '*' ? selectFields : undefined)
          .single();

        const retryResult = await query;
        return retryResult;
      } catch (retryError: any) {
        console.error(`❌ [safeUpsert] Erro no retry:`, retryError);
        return { data: null, error: retryError };
      }
    }

    return { data: null, error };
  }
}

/**
 * Insert seguro
 */
export async function safeInsert<T = any>(
  client: SupabaseClient,
  table: string,
  data: any,
  selectFields: string = '*'
): Promise<{ data: T | null; error: any }> {
  try {
    const sanitizedData = sanitizeDbData(data, ['updated_at']);

    const query = client
      .from(table)
      .insert(sanitizedData);

    if (selectFields !== '*') {
      query.select(selectFields);
    } else {
      query.select();
    }

    const result = await query.single();
    return result;
  } catch (error: any) {
    console.error(`❌ [safeInsert] Erro ao fazer insert em ${table}:`, error);
    
    if (error.message?.includes('updated_at') || error.message?.includes('has no field')) {
      const sanitizedData = sanitizeDbData(data, ['updated_at']);
      const query = client
        .from(table)
        .insert(sanitizedData)
        .select(selectFields !== '*' ? selectFields : undefined)
        .single();

      try {
        const retryResult = await query;
        return retryResult;
      } catch (retryError: any) {
        return { data: null, error: retryError };
      }
    }

    return { data: null, error };
  }
}

/**
 * Update seguro
 */
export async function safeUpdate<T = any>(
  client: SupabaseClient,
  table: string,
  data: any,
  filter: Record<string, any>,
  selectFields: string = '*'
): Promise<{ data: T | null; error: any }> {
  try {
    const sanitizedData = sanitizeDbData(data, ['updated_at']);

    let query = client.from(table).update(sanitizedData);

    // Aplicar filtros
    for (const [key, value] of Object.entries(filter)) {
      query = query.eq(key, value) as any;
    }

    if (selectFields !== '*') {
      query = query.select(selectFields) as any;
    } else {
      query = query.select() as any;
    }

    const result = await query.single();
    return result;
  } catch (error: any) {
    console.error(`❌ [safeUpdate] Erro ao fazer update em ${table}:`, error);
    
    if (error.message?.includes('updated_at') || error.message?.includes('has no field')) {
      const sanitizedData = sanitizeDbData(data, ['updated_at']);
      let query = client.from(table).update(sanitizedData);

      for (const [key, value] of Object.entries(filter)) {
        query = query.eq(key, value) as any;
      }

      if (selectFields !== '*') {
        query = query.select(selectFields) as any;
      } else {
        query = query.select() as any;
      }

      try {
        const retryResult = await query.single();
        return retryResult;
      } catch (retryError: any) {
        return { data: null, error: retryError };
      }
    }

    return { data: null, error };
  }
}

