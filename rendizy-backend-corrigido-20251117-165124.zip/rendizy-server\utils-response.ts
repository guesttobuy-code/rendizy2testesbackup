/**
 * UTILS - Response Helpers
 * 
 * Helpers para garantir respostas JSON corretas em todas as rotas
 * Sempre retorna { success: true, data: ... } ou { success: false, error: ... }
 * 
 * @version 1.0.103.400
 */

import { Context } from 'npm:hono';

/**
 * Retorna resposta de sucesso padronizada
 */
export function successResponse<T>(data: T, message?: string) {
  const response: { success: true; data: T; message?: string } = {
    success: true,
    data,
  };

  if (message) {
    response.message = message;
  }

  return response;
}

/**
 * Retorna resposta de erro padronizada
 */
export function errorResponse(error: string | Error, details?: any) {
  const errorMessage = error instanceof Error ? error.message : error;

  const response: { success: false; error: string; details?: any } = {
    success: false,
    error: errorMessage,
  };

  if (details) {
    response.details = details;
  }

  return response;
}

/**
 * Wrapper para rotas que garante resposta JSON sempre
 */
export async function safeJsonResponse<T>(
  c: Context,
  handler: () => Promise<T>,
  options: {
    statusCode?: number;
    onError?: (error: Error) => void;
  } = {}
): Promise<Response> {
  try {
    const result = await handler();

    // Se já for uma resposta do Hono, retornar diretamente
    if (result instanceof Response) {
      return result;
    }

    // Se já for um objeto com success, retornar como está
    if (result && typeof result === 'object' && 'success' in result) {
      return c.json(result, options.statusCode || 200);
    }

    // Caso contrário, wrappear em successResponse
    return c.json(successResponse(result), options.statusCode || 200);
  } catch (error) {
    console.error('❌ [safeJsonResponse] Erro na rota:', error);

    if (options.onError) {
      options.onError(error instanceof Error ? error : new Error(String(error)));
    }

    // Garantir que sempre retornamos JSON
    const errorMsg = error instanceof Error ? error.message : 'Unknown error';
    return c.json(errorResponse(errorMsg), 500);
  }
}

/**
 * Middleware para garantir que todas as respostas sejam JSON
 */
export function ensureJsonResponse() {
  return async (c: Context, next: () => Promise<void>) => {
    await next();

    // Verificar se a resposta já foi enviada
    if (c.res.headers.get('Content-Type')?.includes('application/json')) {
      return;
    }

    // Se não for JSON, converter para JSON
    const body = await c.res.text().catch(() => null);
    
    if (body && !body.trim().startsWith('{') && !body.trim().startsWith('[')) {
      // Se o body não é JSON válido, wrappear em error response
      c.res = c.json(errorResponse('Response is not valid JSON', { body }), 500);
    }
  };
}

