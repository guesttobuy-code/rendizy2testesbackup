/**
 * UTILS - Organization Helpers
 * 
 * Helpers para garantir que organizationId sempre seja válido
 * Implementa fallback seguro quando organizationId é undefined
 * 
 * @version 1.0.103.400
 */

import * as kv from './kv_store.tsx';
import { Context } from 'npm:hono';

interface Organization {
  id: string;
  slug: string;
  name: string;
  email: string;
  createdBy: string;
  createdAt: string;
}

interface User {
  id: string;
  organizationId: string;
  email: string;
  name: string;
}

interface Session {
  userId: string;
  type: 'superadmin' | 'imobiliaria';
  imobiliariaId?: string;
}

/**
 * Obtém organizationId válido com fallback automático
 * 
 * Ordem de prioridade:
 * 1. organizationId do parâmetro/query/body (se válido)
 * 2. organizationId do usuário logado (via token)
 * 3. Primeira organização do usuário
 * 4. Criar organização automaticamente (se necessário)
 * 
 * @param c - Context do Hono
 * @param paramName - Nome do parâmetro que contém organizationId (default: 'organization_id')
 * @returns Promise<string> - organizationId válido
 */
export async function ensureOrganizationId(
  c: Context,
  paramName: string = 'organization_id'
): Promise<string> {
  try {
    // 1. Tentar obter do parâmetro da rota
    const paramId = c.req.param('id') || c.req.param('orgId') || c.req.param(paramName);
    if (paramId && paramId !== 'undefined' && paramId !== 'null') {
      // Validar se a organização existe
      const org = await kv.get<Organization>(`org:${paramId}`);
      if (org) {
        console.log(`✅ [ensureOrganizationId] Usando organizationId do parâmetro: ${paramId}`);
        return paramId;
      }
    }

    // 2. Tentar obter do query string
    const url = new URL(c.req.url);
    const queryId = url.searchParams.get(paramName) || 
                    url.searchParams.get('organizationId') ||
                    url.searchParams.get('orgId');
    if (queryId && queryId !== 'undefined' && queryId !== 'null') {
      const org = await kv.get<Organization>(`org:${queryId}`);
      if (org) {
        console.log(`✅ [ensureOrganizationId] Usando organizationId do query: ${queryId}`);
        return queryId;
      }
    }

    // 3. Tentar obter do body (para POST/PATCH)
    try {
      const body = await c.req.json().catch(() => ({}));
      const bodyId = body[paramName] || body.organizationId || body.orgId;
      if (bodyId && bodyId !== 'undefined' && bodyId !== 'null') {
        const org = await kv.get<Organization>(`org:${bodyId}`);
        if (org) {
          console.log(`✅ [ensureOrganizationId] Usando organizationId do body: ${bodyId}`);
          return bodyId;
        }
      }
    } catch {
      // Ignorar se body não existir ou não for JSON
    }

    // 4. Tentar obter do usuário logado (via token)
    const token = c.req.header('Authorization')?.split(' ')[1];
    if (token) {
      try {
        const session = await kv.get<Session>(`session:${token}`);
        if (session && session.imobiliariaId) {
          const org = await kv.get<Organization>(`org:${session.imobiliariaId}`);
          if (org) {
            console.log(`✅ [ensureOrganizationId] Usando organizationId da sessão: ${session.imobiliariaId}`);
            return session.imobiliariaId;
          }
        }

        // Buscar usuário e pegar organizationId dele
        if (session && session.userId) {
          const allUsers = await kv.getByPrefix<User>('user:');
          const user = allUsers.find((u: User) => u.id === session.userId);
          
          if (user && user.organizationId) {
            const org = await kv.get<Organization>(`org:${user.organizationId}`);
            if (org) {
              console.log(`✅ [ensureOrganizationId] Usando organizationId do usuário: ${user.organizationId}`);
              return user.organizationId;
            }
          }
        }
      } catch (error) {
        console.warn('⚠️ [ensureOrganizationId] Erro ao buscar sessão:', error);
      }
    }

    // 5. Buscar primeira organização disponível
    const allOrgs = await kv.getByPrefix<Organization>('org:');
    if (allOrgs.length > 0) {
      const firstOrg = allOrgs.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )[0];
      console.log(`✅ [ensureOrganizationId] Usando primeira organização encontrada: ${firstOrg.id}`);
      return firstOrg.id;
    }

    // 6. Criar organização automaticamente (último recurso)
    console.log('⚠️ [ensureOrganizationId] Nenhuma organização encontrada, criando automaticamente...');
    const newOrgId = await createDefaultOrganization();
    console.log(`✅ [ensureOrganizationId] Organização criada automaticamente: ${newOrgId}`);
    return newOrgId;

  } catch (error) {
    console.error('❌ [ensureOrganizationId] Erro ao garantir organizationId:', error);
    
    // Fallback final: retornar organização padrão ou criar uma nova
    try {
      const allOrgs = await kv.getByPrefix<Organization>('org:');
      if (allOrgs.length > 0) {
        return allOrgs[0].id;
      }
      return await createDefaultOrganization();
    } catch {
      throw new Error('Não foi possível obter ou criar uma organização válida');
    }
  }
}

/**
 * Cria uma organização padrão
 */
async function createDefaultOrganization(): Promise<string> {
  const id = `org_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const now = new Date().toISOString();

  const organization: Organization = {
    id,
    slug: `rendizy_${id}`,
    name: 'Organização Padrão',
    email: 'default@rendizy.com',
    createdBy: 'system',
    createdAt: now,
  };

  await kv.set(`org:${id}`, organization);
  return id;
}

/**
 * Valida se organizationId é válido
 */
export async function validateOrganizationId(organizationId: string | undefined | null): Promise<boolean> {
  if (!organizationId || organizationId === 'undefined' || organizationId === 'null') {
    return false;
  }

  try {
    const org = await kv.get<Organization>(`org:${organizationId}`);
    return !!org;
  } catch {
    return false;
  }
}

