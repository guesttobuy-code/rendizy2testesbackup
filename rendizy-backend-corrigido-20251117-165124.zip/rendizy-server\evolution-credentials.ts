/**
 * Evolution API Credentials Manager
 * 
 * Busca credenciais da Evolution API por usuário (multi-tenant)
 * Se o usuário não tiver configuração própria, usa a do superadmin (user_id = 1)
 */

import * as kv from './kv_store.tsx';

export interface EvolutionCredentials {
  instanceName: string;
  instanceApiKey: string;
  globalApiKey: string;
  baseUrl: string;
  source: 'user' | 'superadmin' | 'env';
}

/**
 * Busca credenciais da Evolution API para um usuário
 * 
 * Ordem de prioridade:
 * 1. Credenciais do usuário (tabela evolution_instances)
 * 2. Credenciais do superadmin (user_id = 1)
 * 3. Credenciais do .env (fallback final)
 */
export async function getEvolutionCredentials(userId: number): Promise<EvolutionCredentials> {
  console.log(`🔑 [Evolution] Buscando credenciais para user_id: ${userId}`);
  
  const client = kv.getSupabaseClient();
  
  // 1️⃣ Tentar buscar credenciais do usuário
  // ⚠️ NOTA: Não incluímos updated_at pois o campo pode não existir na tabela
  const { data: userInstance, error: userError } = await client
    .from('evolution_instances')
    .select('id, user_id, instance_name, instance_api_key, global_api_key, base_url, created_at')
    .eq('user_id', userId)
    .maybeSingle();
  
  if (userInstance && !userError) {
    console.log(`✅ [Evolution] Credenciais encontradas para user_id: ${userId}`);
    return {
      instanceName: userInstance.instance_name,
      instanceApiKey: userInstance.instance_api_key,
      globalApiKey: userInstance.global_api_key || '',
      baseUrl: normalizeUrl(userInstance.base_url),
      source: 'user'
    };
  }
  
  console.log(`ℹ️ [Evolution] Usuário ${userId} não tem credenciais próprias, buscando superadmin...`);
  
  // 2️⃣ Buscar credenciais do superadmin (user_id = 1)
  // ⚠️ NOTA: Não incluímos updated_at pois o campo pode não existir na tabela
  const { data: adminInstance, error: adminError } = await client
    .from('evolution_instances')
    .select('id, user_id, instance_name, instance_api_key, global_api_key, base_url, created_at')
    .eq('user_id', 1)
    .maybeSingle();
  
  if (adminInstance && !adminError) {
    console.log(`✅ [Evolution] Usando credenciais do superadmin (user_id: 1)`);
    return {
      instanceName: adminInstance.instance_name,
      instanceApiKey: adminInstance.instance_api_key,
      globalApiKey: adminInstance.global_api_key || '',
      baseUrl: normalizeUrl(adminInstance.base_url),
      source: 'superadmin'
    };
  }
  
  console.log(`⚠️ [Evolution] Superadmin sem credenciais, usando variáveis de ambiente`);
  
  // 3️⃣ Fallback: variáveis de ambiente
  const envInstanceName = Deno.env.get('EVOLUTION_INSTANCE_NAME');
  const envInstanceKey = Deno.env.get('EVOLUTION_INSTANCE_API_KEY');
  const envGlobalKey = Deno.env.get('EVOLUTION_GLOBAL_API_KEY');
  const envBaseUrl = Deno.env.get('EVOLUTION_BASE_URL');
  
  if (!envInstanceName || !envInstanceKey || !envGlobalKey || !envBaseUrl) {
    throw new Error('❌ Nenhuma credencial Evolution encontrada (banco ou .env)');
  }
  
  console.log(`✅ [Evolution] Usando credenciais das variáveis de ambiente`);
  return {
    instanceName: envInstanceName,
    instanceApiKey: envInstanceKey,
    globalApiKey: envGlobalKey,
    baseUrl: normalizeUrl(envBaseUrl),
    source: 'env'
  };
}

/**
 * Normaliza URL removendo barra final
 */
function normalizeUrl(url: string): string {
  return url.replace(/\/+$/, '');
}

/**
 * Obtém headers para requisições à Evolution API
 */
export function getEvolutionHeaders(credentials: EvolutionCredentials): Record<string, string> {
  return {
    'apikey': credentials.globalApiKey,
    'instanceToken': credentials.instanceApiKey,
    'Content-Type': 'application/json'
  };
}

/**
 * Obtém headers para endpoints de mensagens (apenas apikey)
 */
export function getEvolutionMessageHeaders(credentials: EvolutionCredentials): Record<string, string> {
  return {
    'apikey': credentials.globalApiKey,
    'Content-Type': 'application/json'
  };
}



