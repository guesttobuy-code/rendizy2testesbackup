/**
 * RENDIZY - WhatsApp Integration (Evolution API)
 * 
 * Integração completa com Evolution API para WhatsApp
 * Permite conectar instâncias WhatsApp e gerenciar configurações
 * 
 * @figma@ - Modificado em 06/11/2025:
 * - Adicionada nova aba "Webhooks" (linha 583-586)
 * - Import do WhatsAppWebhookManager (linha 28)
 * - Grid expandido de 4 para 5 colunas (linha 570)
 * - Ícone Webhook do lucide-react adicionado
 * 
 * @version 1.0.103.322 (webhooks) / 1.0.103.42 (base)
 * @date 2025-11-06 / 2025-10-29
 */

import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { WhatsAppCredentialsTester } from './WhatsAppCredentialsTester';
import WhatsAppWebhookManager from './WhatsAppWebhookManager';
import {
  MessageCircle,
  Key,
  CheckCircle2,
  XCircle,
  Loader2,
  AlertCircle,
  Eye,
  EyeOff,
  QrCode,
  Link2,
  Copy,
  CheckCircle,
  RefreshCw,
  Settings,
  Phone,
  Zap,
  Webhook,
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { channelsApi, OrganizationChannelConfig } from '../utils/chatApi';
import { isOfflineMode } from '../utils/offlineConfig';
import { evolutionService, SessionStatus } from '../utils/services/evolutionService';

// ============================================================================
// TYPES
// ============================================================================

interface WhatsAppConfig {
  api_url: string;
  instance_name: string;
  api_key: string;
  enabled: boolean;
  connected: boolean;
  connection_status: 'disconnected' | 'connecting' | 'connected' | 'error';
  phone_number?: string;
  lastSync?: string;
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export default function WhatsAppIntegration() {
  const organizationId = 'org_default'; // TODO: Get from context/props
  
  const [loading, setLoading] = useState(true);
  const [config, setConfig] = useState<OrganizationChannelConfig | null>(null);
  const [whatsappForm, setWhatsappForm] = useState({
    api_url: '',
    instance_name: '',
    api_key: '',
    instance_token: '' // Adicionado Instance Token
  });
  
  const [showApiKey, setShowApiKey] = useState(false);
  const [showInstanceToken, setShowInstanceToken] = useState(false); // Toggle para Instance Token
  const [connectingWhatsApp, setConnectingWhatsApp] = useState(false);
  const [savingConfig, setSavingConfig] = useState(false);
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [realTimeStatus, setRealTimeStatus] = useState<SessionStatus | null>(null);
  const [checkingStatus, setCheckingStatus] = useState(false);
  const [activeTab, setActiveTab] = useState('config');
  
  // Webhook URL para Evolution API
  const webhookUrl = `https://${projectId}.supabase.co/functions/v1/rendizy-server/chat/channels/whatsapp/webhook`;

  useEffect(() => {
    loadConfig();
  }, [organizationId]);

  /**
   * Verificar status real da conexão WhatsApp
   */
  const checkWhatsAppStatus = async () => {
    if (!config?.whatsapp?.enabled) {
      return;
    }

    setCheckingStatus(true);
    try {
      console.log('🔍 [WhatsApp] Verificando status da conexão...');
      // ✅ Passar organization_id para o serviço
      const status = await evolutionService.getStatus(organizationId);
      console.log('📊 [WhatsApp] Status recebido:', status);
      setRealTimeStatus(status);

      // Atualizar config se status mudou
      if (config) {
        const wasConnected = config.whatsapp?.connected || false;
        const isConnected = status === 'CONNECTED';
        
        if (wasConnected !== isConnected) {
          console.log(`🔄 [WhatsApp] Status mudou: ${wasConnected ? 'Online' : 'Offline'} → ${isConnected ? 'Online' : 'Offline'}`);
          
          // Atualizar config local
          setConfig({
            ...config,
            whatsapp: {
              ...config.whatsapp,
              connected: isConnected,
              connection_status: isConnected ? 'connected' : 'disconnected'
            }
          });

          // Mostrar notificação se conectou
          if (isConnected && !wasConnected) {
            toast.success('✅ WhatsApp conectado com sucesso!', { duration: 3000 });
          }
        }
      }
    } catch (error) {
      console.error('❌ [WhatsApp] Erro ao verificar status:', error);
      setRealTimeStatus('ERROR');
    } finally {
      setCheckingStatus(false);
    }
  };

  // Polling automático de status quando estiver na aba "Status & Conexão"
  useEffect(() => {
    if (activeTab !== 'status' || !config?.whatsapp?.enabled) {
      return;
    }

    // Verificar status imediatamente ao abrir a aba
    checkWhatsAppStatus();

    // Polling a cada 5 segundos
    const interval = setInterval(() => {
      checkWhatsAppStatus();
    }, 5000);

    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, config?.whatsapp?.enabled]);

  const loadConfig = async () => {
    setLoading(true);
    
    console.log('📡 [WhatsApp] Carregando configurações do Supabase...');
    
    try {
      const result = await channelsApi.getConfig(organizationId);
      
      if (result.success && result.data) {
        console.log('✅ [WhatsApp] Configurações carregadas do banco');
        console.log('📋 [WhatsApp] Dados recebidos:', JSON.stringify(result.data, null, 2));
        setConfig(result.data);
        
        if (result.data.whatsapp) {
          const formData = {
            api_url: result.data.whatsapp.api_url || '',
            instance_name: result.data.whatsapp.instance_name || '',
            api_key: result.data.whatsapp.api_key || '',
            instance_token: result.data.whatsapp.instance_token || ''
          };
          console.log('📝 [WhatsApp] Preenchendo formulário:', formData);
          setWhatsappForm(formData);
        } else {
          console.warn('⚠️ [WhatsApp] result.data.whatsapp não existe:', result.data);
        }
      } else {
        console.log('ℹ️ [WhatsApp] Nenhuma configuração encontrada (usando padrão)');
      }
    } catch (error) {
      console.error('❌ [WhatsApp] Erro ao carregar configurações:', error);
      
      // Se backend não estiver disponível, mostrar erro
      toast.error('Não foi possível carregar configurações. Verifique se o backend está online.', {
        duration: 5000
      });
    }
    
    setLoading(false);
  };

  const handleCopyWebhook = async () => {
    try {
      await navigator.clipboard.writeText(webhookUrl);
      toast.success('URL do webhook copiada!');
    } catch (err) {
      // Fallback: criar textarea temporário
      const textArea = document.createElement('textarea');
      textArea.value = webhookUrl;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        toast.success('URL do webhook copiada!');
      } catch (e) {
        toast.error('Não foi possível copiar. Copie manualmente.');
      }
      document.body.removeChild(textArea);
    }
  };

  const handleTestConnection = async () => {
    if (!whatsappForm.api_url || !whatsappForm.instance_name || !whatsappForm.api_key) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    // Limpar e validar URL
    let cleanUrl = whatsappForm.api_url.trim();
    
    // Remover /manager se existir
    if (cleanUrl.endsWith('/manager')) {
      cleanUrl = cleanUrl.replace(/\/manager\/?$/, '');
      setWhatsappForm(prev => ({ ...prev, api_url: cleanUrl }));
      toast.info('✨ URL ajustada: /manager removido', { duration: 3000 });
    }
    
    // Remover barra final
    cleanUrl = cleanUrl.replace(/\/$/, '');
    
    // Validar URL
    if (cleanUrl === 'https://api.evolutionapi.com') {
      toast.error('⚠️ URL de exemplo detectada! Use a URL REAL da sua Evolution API', {
        duration: 6000,
      });
      setConnectionStatus('error');
      return;
    }

    if (!cleanUrl.startsWith('http')) {
      toast.error('❌ URL inválida! Deve começar com http:// ou https://');
      setConnectionStatus('error');
      return;
    }

    setConnectionStatus('idle');
    setConnectingWhatsApp(true);
    
    try {
      // 🔥 TESTE DIRETO DO FRONTEND - Não depende do backend
      // Testar se conseguimos acessar a API diretamente
      console.log('🧪 Testando conexão direta com Evolution API...');
      console.log('   URL:', cleanUrl);
      console.log('   Instance:', whatsappForm.instance_name.trim());
      console.log('   API Key:', whatsappForm.api_key.substring(0, 10) + '...');
      
      const testUrl = `${cleanUrl}/instance/fetchInstances`;
      console.log('   Endpoint:', testUrl);
      
      const response = await fetch(testUrl, {
        method: 'GET',
        headers: {
          'apikey': whatsappForm.api_key.trim(),
          'Content-Type': 'application/json',
        },
      });

      console.log('   Status:', response.status);

      if (response.status === 401) {
        setConnectionStatus('error');
        toast.error('❌ API Key inválida! Crie uma nova no Evolution Manager', {
          duration: 8000,
        });
        return;
      }

      if (!response.ok) {
        const errorText = await response.text().catch(() => 'Erro desconhecido');
        console.error('   Erro:', errorText);
        setConnectionStatus('error');
        toast.error(`❌ Erro ${response.status}: ${errorText}`, {
          duration: 6000,
        });
        return;
      }

      const data = await response.json();
      console.log('   Resposta:', data);

      // Verificar se a instância existe
      const instances = Array.isArray(data) ? data : [];
      const instanceExists = instances.some((inst: any) => 
        inst.instance?.instanceName === whatsappForm.instance_name.trim()
      );

      if (instanceExists) {
        setConnectionStatus('success');
        toast.success('✅ Conexão OK! Instância encontrada', {
          duration: 5000,
        });
      } else {
        setConnectionStatus('success');
        toast.success(`✅ Conexão OK! Instância "${whatsappForm.instance_name.trim()}" será criada ao conectar`, {
          duration: 6000,
        });
      }
      
      // Salvar configuração após teste bem-sucedido
      await channelsApi.updateConfig(organizationId, {
        whatsapp: {
          enabled: true,
          api_url: cleanUrl,
          instance_name: whatsappForm.instance_name.trim(),
          api_key: whatsappForm.api_key.trim(),
          instance_token: whatsappForm.instance_token.trim(),
          connected: false,
          connection_status: 'disconnected'
        }
      });
      
    } catch (error: any) {
      console.error('❌ Erro ao testar conexão:', error);
      setConnectionStatus('error');
      
      // Mensagens de erro mais específicas
      if (error.message?.includes('Failed to fetch') || error.message?.includes('NetworkError')) {
        toast.error('❌ Não foi possível conectar! Verifique se a URL está correta e acessível', {
          duration: 8000,
        });
      } else if (error.name === 'TypeError') {
        toast.error('❌ URL inválida ou inacessível! Verifique a URL da Evolution API', {
          duration: 8000,
        });
      } else {
        toast.error('❌ Erro ao testar conexão: ' + (error.message || 'Erro desconhecido'), {
          duration: 6000,
        });
      }
    } finally {
      setConnectingWhatsApp(false);
    }
  };

  const handleConnectWhatsApp = async () => {
    if (!whatsappForm.api_url || !whatsappForm.instance_name || !whatsappForm.api_key) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    // Limpar e validar URL
    let cleanUrl = whatsappForm.api_url.trim();
    
    // Remover /manager se existir
    if (cleanUrl.endsWith('/manager')) {
      cleanUrl = cleanUrl.replace(/\/manager\/?$/, '');
      setWhatsappForm(prev => ({ ...prev, api_url: cleanUrl }));
      toast.info('✨ URL ajustada: /manager removido', { duration: 3000 });
    }
    
    // Remover barra final
    cleanUrl = cleanUrl.replace(/\/$/, '');
    
    // Validar URL
    if (cleanUrl === 'https://api.evolutionapi.com') {
      toast.error('⚠️ URL de exemplo detectada! Use a URL REAL da sua Evolution API', {
        duration: 6000,
      });
      return;
    }

    if (!cleanUrl.startsWith('http')) {
      toast.error('❌ URL inválida! Deve começar com http:// ou https://');
      return;
    }

    setConnectingWhatsApp(true);
    setQrCode(null); // Limpar QR Code anterior
    
    try {
      console.log('🔵 Iniciando conexão WhatsApp...');
      console.log('⚠️  A instância existente será deletada e recriada para gerar QR Code válido');
      toast.info('🔄 Deletando instância existente para gerar novo QR Code...', {
        duration: 4000,
      });
      
      // Dados limpos
      const cleanConfig = {
        api_url: cleanUrl,
        instance_name: whatsappForm.instance_name.trim(),
        api_key: whatsappForm.api_key.trim(),
        instance_token: whatsappForm.instance_token.trim() // Adicionado Instance Token
      };
      
      console.log('📤 Enviando request para backend...', cleanConfig);
      
      const result = await channelsApi.evolution.connect(organizationId, cleanConfig);
      
      console.log('📥 Resposta do backend:', result);
      
      if (result.success && result.data) {
        let qrCodeData = result.data.qr_code;
        
        console.log('🔍 QR Code recebido:', qrCodeData ? `${qrCodeData.substring(0, 50)}...` : 'null');
        
        // Se o QR Code for base64 puro, adicionar o prefixo correto
        if (qrCodeData && !qrCodeData.startsWith('data:image')) {
          qrCodeData = `data:image/png;base64,${qrCodeData}`;
          console.log('✨ Prefixo data:image adicionado ao QR Code');
        }
        
        setQrCode(qrCodeData);
        console.log('✅ QR Code definido no state');
        
        toast.success('✅ QR Code gerado! Escaneie com o WhatsApp', {
          duration: 8000,
        });
        
        // NÃO chamar loadConfig() aqui para não sobrescrever o QR Code
        // O QR Code será mantido até que a conexão seja estabelecida
        
      } else {
        console.error('❌ Falha na resposta:', result);
        toast.error('❌ ' + (result.error || 'Erro ao conectar WhatsApp'));
      }
    } catch (error: any) {
      console.error('❌ Error connecting WhatsApp:', error);
      
      // Mensagens de erro mais específicas
      if (error.message?.includes('401') || error.message?.includes('Unauthorized')) {
        toast.error('❌ API Key inválida! Verifique suas credenciais', {
          duration: 6000,
        });
      } else if (error.message?.includes('404')) {
        toast.error('❌ Endpoint não encontrado! Verifique se a URL está correta', {
          duration: 6000,
        });
      } else if (error.message?.includes('dns error') || error.message?.includes('failed to lookup')) {
        toast.error('❌ URL inválida ou servidor inacessível!', {
          duration: 8000,
        });
      } else if (error.message?.includes('Network Error') || error.message?.includes('Failed to fetch')) {
        toast.error('❌ Erro de conexão! Verifique se o servidor está online', {
          duration: 6000,
        });
      } else {
        toast.error('❌ Erro: ' + (error.message || 'Erro desconhecido'));
      }
    } finally {
      setConnectingWhatsApp(false);
    }
  };

  const handleDisconnectWhatsApp = async () => {
    try {
      const result = await channelsApi.evolution.disconnect(organizationId);
      if (result.success) {
        toast.success('WhatsApp desconectado');
        setQrCode(null);
        await loadConfig();
      }
    } catch (error) {
      console.error('Error disconnecting WhatsApp:', error);
      toast.error('Erro ao desconectar WhatsApp');
    }
  };

  const handleSaveConfig = async () => {
    console.log('🔵 handleSaveConfig chamado');
    console.log('📋 Dados do formulário:', whatsappForm);
    
    setSavingConfig(true);
    
    try {
      // Validar campos obrigatórios
      if (!whatsappForm.api_url || !whatsappForm.instance_name || !whatsappForm.api_key) {
        toast.error('❌ Preencha todos os campos obrigatórios');
        return;
      }
      
      // Limpar e validar dados
      let cleanUrl = whatsappForm.api_url.trim();
      
      console.log('🔵 URL original:', cleanUrl);
      
      // Remover /manager se existir
      if (cleanUrl.endsWith('/manager')) {
        cleanUrl = cleanUrl.replace(/\/manager\/?$/, '');
        console.log('✨ URL ajustada (removido /manager):', cleanUrl);
        toast.info('✨ URL ajustada: /manager removido', { duration: 3000 });
      }
      
      // Remover barra final
      cleanUrl = cleanUrl.replace(/\/$/, '');
      
      console.log('🔵 URL limpa:', cleanUrl);
      
      // Validar
      if (!cleanUrl || cleanUrl === 'https://api.evolutionapi.com') {
        console.error('❌ URL de exemplo ou vazia');
        toast.error('❌ Use a URL REAL da sua Evolution API');
        return;
      }
      
      if (!cleanUrl.startsWith('http')) {
        console.error('❌ URL não começa com http');
        toast.error('❌ URL inválida! Deve começar com http:// ou https://');
        return;
      }
      
      const configToSave = {
        whatsapp: {
          ...config?.whatsapp,
          enabled: true,
          api_url: cleanUrl,
          instance_name: whatsappForm.instance_name.trim(),
          api_key: whatsappForm.api_key.trim(),
          instance_token: whatsappForm.instance_token.trim(),
          connected: config?.whatsapp?.connected || false,
          connection_status: config?.whatsapp?.connection_status || 'disconnected'
        }
      };
      
      console.log('📤 Salvando config:', configToSave);
      
      // 🔥 MODO DESENVOLVIMENTO - Salvar localmente (backend não deployado ainda)
      // Quando o backend for deployado, isso funcionará automaticamente via API
      
      try {
        // Tentar salvar no backend (se estiver deployado)
        const result = await channelsApi.updateConfig(organizationId, configToSave);
        
        console.log('📥 Resultado:', result);
        
        if (result.success) {
          setConfig(result.data);
          setWhatsappForm(prev => ({ ...prev, api_url: cleanUrl }));
          console.log('✅ Configurações salvas no backend!');
          toast.success('✅ Configurações salvas no servidor!');
        } else {
          throw new Error(result.error || 'Backend returned error');
        }
      } catch (fetchError: any) {
        // Backend não disponível - mostrar erro
        console.error('❌ Backend não disponível:', fetchError.message || fetchError);
        
        toast.error('❌ Falha ao salvar configurações!', {
          description: 'Backend não está acessível. Verifique se foi deployado.',
          duration: 8000,
        });
        
        toast.info('💡 Como resolver:', {
          description: '1. Execute o SQL no Supabase\n2. Faça deploy da Edge Function\n3. Veja: DEPLOY_SUPABASE.md',
          duration: 10000,
        });
      }
    } catch (error: any) {
      console.error('❌ Error saving WhatsApp config:', error);
      toast.error('❌ Erro ao salvar: ' + (error.message || 'Erro desconhecido'));
    } finally {
      setSavingConfig(false);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <Loader2 className="h-8 w-8 text-green-500 mx-auto mb-4 animate-spin" />
        <p className="text-muted-foreground">Carregando configurações do WhatsApp...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* MODO OFFLINE WARNING */}
      {config?.message?.includes('modo offline') && (
        <Alert className="bg-yellow-50 border-yellow-300">
          <AlertCircle className="h-4 w-4 text-yellow-700" />
          <AlertDescription className="text-yellow-900">
            <div className="space-y-2">
              <p className="font-medium">🔄 Modo Offline Ativo</p>
              <p className="text-sm">
                O backend não está acessível. Suas configurações estão sendo salvas localmente no navegador.
              </p>
              <p className="text-sm">
                <strong>Para ativar o backend:</strong>
              </p>
              <div className="bg-yellow-100 rounded px-3 py-2 mt-2 font-mono text-xs">
                bash DEPLOY_BACKEND_NOW.sh
              </div>
              <p className="text-xs mt-2">
                📚 Veja mais detalhes em: <code className="bg-yellow-100 px-1 rounded">SOLUCAO_RAPIDA_BACKEND.md</code>
              </p>
            </div>
          </AlertDescription>
        </Alert>
      )}
      
      {/* HEADER */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center">
            <MessageCircle className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">WhatsApp Business</h2>
            <p className="text-sm text-muted-foreground">
              Integração com Evolution API • Receba e envie mensagens
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {config?.whatsapp?.connected && (
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Conectado
            </Badge>
          )}
          
          {config?.whatsapp?.lastSync && (
            <Badge variant="outline">
              Última sincronização: {new Date(config.whatsapp.lastSync).toLocaleString('pt-BR')}
            </Badge>
          )}
        </div>
      </div>

      <Tabs defaultValue="config" className="space-y-6" onValueChange={(value) => setActiveTab(value)}>
        <TabsList className="w-full flex flex-wrap gap-3">
          <TabsTrigger value="test" className="flex-none justify-center px-4 py-2 min-w-[150px]">
            <RefreshCw className="w-4 h-4 mr-2" />
            Testar
          </TabsTrigger>
          <TabsTrigger value="config" className="flex-none justify-center px-4 py-2 min-w-[150px]">
            <Key className="w-4 h-4 mr-2" />
            Configuração
          </TabsTrigger>
          <TabsTrigger value="status" className="flex-none justify-center px-4 py-2 min-w-[150px]">
            <Zap className="w-4 h-4 mr-2" />
            Status & Conexão
          </TabsTrigger>
          <TabsTrigger value="webhooks" className="flex-none justify-center px-4 py-2 min-w-[150px]">
            <Webhook className="w-4 h-4 mr-2" />
            Webhooks
          </TabsTrigger>
          <TabsTrigger value="advanced" className="flex-none justify-center px-4 py-2 min-w-[150px]">
            <Settings className="w-4 h-4 mr-2" />
            Avançado
          </TabsTrigger>
        </TabsList>

        {/* TAB 0: TESTAR CREDENCIAIS */}
        <TabsContent value="test" className="space-y-6">
          <WhatsAppCredentialsTester />
        </TabsContent>

        {/* TAB 1: CONFIGURAÇÃO */}
        <TabsContent value="config" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Credenciais da Evolution API</CardTitle>
              <CardDescription>
                Configure suas credenciais de acesso à Evolution API para conectar o WhatsApp
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Status da Conexão */}
              {config?.whatsapp?.enabled && (
                <Alert className={config?.whatsapp?.connected ? 'bg-green-50 border-green-300' : 'bg-yellow-50 border-yellow-300'}>
                  {config?.whatsapp?.connected ? (
                    <CheckCircle2 className="h-4 w-4 text-green-700" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-yellow-700" />
                  )}
                  <AlertDescription className={config?.whatsapp?.connected ? 'text-green-900' : 'text-yellow-900'}>
                    {config?.whatsapp?.connected ? (
                      <div className="space-y-2">
                        <p className="text-sm"><strong>✅ WhatsApp Conectado</strong></p>
                        {config?.whatsapp?.phone_number && (
                          <p className="text-xs">
                            Número: <code className="bg-green-100 px-1 rounded">{config.whatsapp.phone_number}</code>
                          </p>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={handleDisconnectWhatsApp}
                          className="mt-2 border-red-500 text-red-500 hover:bg-red-500/10"
                        >
                          <XCircle className="w-4 h-4 mr-2" />
                          Desconectar
                        </Button>
                      </div>
                    ) : (
                      <div>
                        <p className="text-sm"><strong>⚠️ WhatsApp Desconectado</strong></p>
                        <p className="text-xs mt-1">Configure abaixo e gere o QR Code para conectar</p>
                      </div>
                    )}
                  </AlertDescription>
                </Alert>
              )}

              <Separator />

              {/* URL da Evolution API */}
              <div className="space-y-2">
                <Label htmlFor="api_url">URL da Evolution API</Label>
                <div className="flex gap-2">
                  <Link2 className="w-5 h-5 text-muted-foreground mt-2" />
                  <Input
                    id="api_url"
                    value={whatsappForm.api_url}
                    onChange={(e) => setWhatsappForm({ ...whatsappForm, api_url: e.target.value })}
                    placeholder="https://evo.boravendermuito.com.br"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  💡 URL base da sua instância Evolution API (Ex: https://evo.boravendermuito.com.br)
                </p>
              </div>

              {/* Nome da Instância */}
              <div className="space-y-2">
                <Label htmlFor="instance_name">Nome da Instância</Label>
                <div className="flex gap-2">
                  <Phone className="w-5 h-5 text-muted-foreground mt-2" />
                  <Input
                    id="instance_name"
                    value={whatsappForm.instance_name}
                    onChange={(e) => setWhatsappForm({ ...whatsappForm, instance_name: e.target.value })}
                    placeholder="rendizy-admin-master"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  💡 Identificador único da sua instância (Ex: rendizy-admin-master)
                </p>
              </div>

              {/* API Key */}
              <div className="space-y-2">
                <Label htmlFor="api_key">API Key</Label>
                <div className="flex gap-2">
                  <Key className="w-5 h-5 text-muted-foreground mt-2" />
                  <div className="flex-1 relative">
                    <Input
                      id="api_key"
                      type={showApiKey ? 'text' : 'password'}
                      value={whatsappForm.api_key}
                      onChange={(e) => setWhatsappForm({ ...whatsappForm, api_key: e.target.value })}
                      placeholder="sua-api-key-aqui"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                      onClick={() => setShowApiKey(!showApiKey)}
                    >
                      {showApiKey ? (
                        <EyeOff className="w-4 h-4 text-muted-foreground" />
                      ) : (
                        <Eye className="w-4 h-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  🔒 Chave de autenticação da Evolution API
                </p>
              </div>

              {/* Instance Token */}
              <div className="space-y-2">
                <Label htmlFor="instance_token">Instance Token</Label>
                <div className="flex gap-2">
                  <Key className="w-5 h-5 text-muted-foreground mt-2" />
                  <div className="flex-1 relative">
                    <Input
                      id="instance_token"
                      type={showInstanceToken ? 'text' : 'password'}
                      value={whatsappForm.instance_token}
                      onChange={(e) => setWhatsappForm({ ...whatsappForm, instance_token: e.target.value })}
                      placeholder="seu-instance-token-aqui"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                      onClick={() => setShowInstanceToken(!showInstanceToken)}
                    >
                      {showInstanceToken ? (
                        <EyeOff className="w-4 h-4 text-muted-foreground" />
                      ) : (
                        <Eye className="w-4 h-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  🔒 Token de instância da Evolution API
                </p>
              </div>

              <Separator />

              {/* URL do Webhook */}
              <div className="space-y-2">
                <Label>URL do Webhook</Label>
                <div className="flex gap-2">
                  <Input
                    value={webhookUrl}
                    readOnly
                    className="bg-muted font-mono text-xs"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyWebhook}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  📡 Configure este webhook na Evolution API para receber mensagens automaticamente
                </p>
              </div>

              <Separator />

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button
                  onClick={handleTestConnection}
                  disabled={connectingWhatsApp}
                  variant="outline"
                  className="flex-1"
                >
                  {connectingWhatsApp ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Testando...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Testar Conexão
                    </>
                  )}
                </Button>
                
                <Button
                  onClick={handleSaveConfig}
                  disabled={savingConfig}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  {savingConfig ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Salvar Configurações
                    </>
                  )}
                </Button>
              </div>

              {/* Connection Status */}
              {connectionStatus !== 'idle' && (
                <Alert className={connectionStatus === 'success' ? 'bg-green-50 border-green-300' : 'bg-red-50 border-red-300'}>
                  {connectionStatus === 'success' ? (
                    <CheckCircle2 className="h-4 w-4 text-green-700" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-700" />
                  )}
                  <AlertDescription className={connectionStatus === 'success' ? 'text-green-900' : 'text-red-900'}>
                    {connectionStatus === 'success' 
                      ? '✅ Conexão estabelecida com sucesso!'
                      : '❌ Falha ao conectar. Verifique as credenciais.'}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* TAB 2: STATUS & CONEXÃO */}
        <TabsContent value="status" className="space-y-6" onValueChange={() => setActiveTab('status')}>
          <Card>
            <CardHeader>
              <CardTitle>Conectar WhatsApp</CardTitle>
              <CardDescription>
                Gere um QR Code para conectar seu WhatsApp ao RENDIZY
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!config?.whatsapp?.connected ? (
                <>
                  <Button
                    onClick={handleConnectWhatsApp}
                    disabled={connectingWhatsApp || !whatsappForm.api_url || !whatsappForm.instance_name || !whatsappForm.api_key}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    {connectingWhatsApp ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Conectando...
                      </>
                    ) : (
                      <>
                        <QrCode className="h-4 w-4 mr-2" />
                        Gerar QR Code
                      </>
                    )}
                  </Button>

                  {!whatsappForm.api_url || !whatsappForm.instance_name || !whatsappForm.api_key ? (
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        ℹ️ Preencha todos os campos na aba "Configuração" antes de gerar o QR Code
                      </AlertDescription>
                    </Alert>
                  ) : null}

                  {/* QR Code Display */}
                  {qrCode && (
                    <div className="p-6 rounded-lg bg-muted border border-border text-center">
                      <QrCode className="h-8 w-8 mx-auto mb-3 text-green-500" />
                      <p className="text-sm text-foreground mb-4">
                        ✅ QR Code gerado! Escaneie com o WhatsApp
                      </p>
                      <div className="bg-white p-4 inline-block rounded-lg shadow-lg">
                        {qrCode.startsWith('data:image') ? (
                          <img 
                            src={qrCode} 
                            alt="WhatsApp QR Code" 
                            className="w-64 h-64 object-contain"
                          />
                        ) : (
                          <div className="w-64 h-64 bg-white flex items-center justify-center p-2">
                            <code className="text-xs break-all">{qrCode}</code>
                          </div>
                        )}
                      </div>
                      <div className="mt-4 text-left space-y-2 text-sm text-muted-foreground">
                        <p><strong>📱 Como conectar:</strong></p>
                        <ol className="list-decimal list-inside space-y-1 ml-4">
                          <li>Abra o WhatsApp no seu celular</li>
                          <li>Toque em Menu (⋮) e depois em "Aparelhos conectados"</li>
                          <li>Toque em "Conectar um aparelho"</li>
                          <li>Aponte a câmera para este QR Code</li>
                        </ol>
                      </div>
                      
                      {/* Refresh QR Code Button */}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleConnectWhatsApp}
                        disabled={connectingWhatsApp}
                        className="mt-4"
                      >
                        <RefreshCw className={`h-4 w-4 mr-2 ${connectingWhatsApp ? 'animate-spin' : ''}`} />
                        {connectingWhatsApp ? 'Gerando...' : 'Gerar Novo QR Code'}
                      </Button>
                      
                      <p className="text-xs text-muted-foreground mt-2">
                        💡 O QR Code expira após alguns minutos. Se expirar, clique em "Gerar Novo QR Code"
                      </p>
                    </div>
                  )}
                </>
              ) : (
                <Alert className="bg-green-50 border-green-300">
                  <CheckCircle2 className="h-4 w-4 text-green-700" />
                  <AlertDescription className="text-green-900">
                    <div className="space-y-2">
                      <p className="text-sm"><strong>✅ WhatsApp Conectado com Sucesso!</strong></p>
                      {config?.whatsapp?.phone_number && (
                        <p className="text-xs">
                          Número conectado: <code className="bg-green-100 px-2 py-1 rounded">{config.whatsapp.phone_number}</code>
                        </p>
                      )}
                      <p className="text-xs mt-2">
                        Seu WhatsApp está conectado e pronto para receber e enviar mensagens.
                      </p>
                    </div>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Status Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm text-muted-foreground">Status</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0"
                        onClick={checkWhatsAppStatus}
                        disabled={checkingStatus}
                        title="Atualizar status"
                      >
                        <RefreshCw className={`h-3 w-3 ${checkingStatus ? 'animate-spin' : ''}`} />
                      </Button>
                    </div>
                    <p className="text-2xl mt-1">
                      {(() => {
                        // Usar status em tempo real se disponível, senão usar config salva
                        const statusToShow = realTimeStatus !== null 
                          ? realTimeStatus 
                          : (config?.whatsapp?.connected ? 'CONNECTED' : 'DISCONNECTED');
                        
                        if (statusToShow === 'CONNECTED') return 'Online';
                        if (statusToShow === 'CONNECTING') return 'Conectando...';
                        if (statusToShow === 'ERROR') return 'Erro';
                        return 'Offline';
                      })()}
                    </p>
                    {realTimeStatus === 'CONNECTING' && (
                      <p className="text-xs text-muted-foreground mt-1">Aguardando conexão...</p>
                    )}
                  </div>
                  <div className={`w-12 h-12 rounded-full ${
                    (realTimeStatus === 'CONNECTED' || (!realTimeStatus && config?.whatsapp?.connected))
                      ? 'bg-green-500/10' 
                      : realTimeStatus === 'CONNECTING'
                      ? 'bg-yellow-500/10'
                      : 'bg-gray-500/10'
                  } flex items-center justify-center`}>
                    {realTimeStatus === 'CONNECTED' || (!realTimeStatus && config?.whatsapp?.connected) ? (
                      <CheckCircle2 className="h-6 w-6 text-green-500" />
                    ) : realTimeStatus === 'CONNECTING' ? (
                      <Loader2 className="h-6 w-6 text-yellow-500 animate-spin" />
                    ) : (
                      <XCircle className="h-6 w-6 text-gray-500" />
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Mensagens Hoje</p>
                    <p className="text-2xl mt-1">0</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center">
                    <MessageCircle className="h-6 w-6 text-blue-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Taxa de Resposta</p>
                    <p className="text-2xl mt-1">0%</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-purple-500/10 flex items-center justify-center">
                    <Zap className="h-6 w-6 text-purple-500" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* TAB 3: WEBHOOKS */}
        <TabsContent value="webhooks" className="space-y-6">
          <WhatsAppWebhookManager />
        </TabsContent>

        {/* TAB 4: AVANÇADO */}
        <TabsContent value="advanced" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações Avançadas</CardTitle>
              <CardDescription>
                Opções avançadas para usuários experientes
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  🚧 Configurações avançadas serão disponibilizadas em breve
                </AlertDescription>
              </Alert>
              
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Recursos Planejados:</h4>
                <ul className="text-sm text-muted-foreground space-y-1 ml-4 list-disc">
                  <li>Configuração de respostas automáticas</li>
                  <li>Agendamento de mensagens</li>
                  <li>Templates de mensagens personalizados</li>
                  <li>Integração com chatbots</li>
                  <li>Relatórios e analytics detalhados</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}